<?php
require_once __DIR__ . '/../../lib/db.php';
require_once __DIR__ . '/../../lib/coreFunction.php';

$db = new Database();
$core = new CoreFunction($db);

// Lấy danh sách sản phẩm chưa bị xóa
$products = $core->getProducts();
?>

<div class="admin-main">
<h2>Danh sách sản phẩm</h2>
<table border="1" cellspacing="0" cellpadding="8" style="border-collapse: collapse; width:100%;">
    <tr style="background:#007bff; color:#fff; text-align:center;">
        <th>ID</th>
        <th>Tên</th>
        <th>Danh mục</th>
        <th>Giá</th>
        <th>Ảnh</th>
        <th>Hành động</th>
    </tr>

    <?php if (!empty($products)): ?>
        <?php foreach ($products as $p): ?>
            <tr style="text-align:center;">
                <td><?= htmlspecialchars($p['id']) ?></td>
                <td><?= htmlspecialchars($p['name']) ?></td>
                <td><?= htmlspecialchars($p['category_name']) ?></td>
                <td><?= number_format($p['price'], 0, ',', '.') ?> đ</td>
                <td>
                    <?php if (!empty($p['image'])): ?>
                        <img src="/VoHoMinhQuan_2124110160/asset/images/<?= htmlspecialchars($p['image']) ?>" 
                        alt="<?= htmlspecialchars($p['name']) ?>" width="80" 
                        onerror="this.src='/VoHoMinhQuan_2124110160/asset/images/no-image.png';">
                    <?php else: ?>
                        <em>Không có ảnh</em>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="index.php?page=product_edit&id=<?= $p['id'] ?>">✏️ Sửa</a> |
                    <a href="index.php?page=product_delete&id=<?= $p['id'] ?>"
                       onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này không?')">🗑️ Xóa</a>
                </td>
            </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr><td colspan="6" style="text-align:center;">Không có sản phẩm nào.</td></tr>
    <?php endif; ?>
</table>
<br>
<a href="index.php?page=product_add">➕ Thêm sản phẩm mới</a>
</div>