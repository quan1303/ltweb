<?php
require_once(__DIR__ . '/../../lib/db.php');
require_once(__DIR__ . '/../../lib/coreFunction.php');

$db = new Database();
$core = new CoreFunction($db);

$id = $_GET['id'] ?? 0;

if ($id) {
    // Kiểm tra xem sản phẩm đã được đặt hàng chưa
    if ($core->isProductOrdered($id)) {
        echo "<script>
                alert('❌ Không thể xóa! Sản phẩm này đã được đặt hàng.');
                window.location.href = 'index.php?page=product_list';
              </script>";
        exit;
    }

    // Nếu chưa được đặt hàng, cho phép xóa mềm
    $core->DeleteProduct($id);

    echo "<script>
            alert('✅ Đã xóa sản phẩm thành công!');
            window.location.href = 'index.php?page=product_list';
          </script>";
    exit;
}
?>
