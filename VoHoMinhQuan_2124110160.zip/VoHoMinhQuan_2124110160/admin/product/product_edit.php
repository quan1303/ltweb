<?php
require_once __DIR__ . '/../../lib/db.php';
require_once __DIR__ . '/../../lib/coreFunction.php';

$db = new Database();
$core = new CoreFunction($db);

// Lấy ID sản phẩm
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$product = $core->getProductById($id);
$categories = $core->getCategories();
$msg = '';

// Nếu không tìm thấy sản phẩm
if (!$product) {
    echo "<p>❌ Không tìm thấy sản phẩm cần sửa!</p>";
    exit;
}

// Xử lý khi form được submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $slug = strtolower(str_replace(' ', '-', $name));
    $price = (int)$_POST['price'];
    $category_id = (int)$_POST['category_id'];
    $image = trim($_POST['image']);
    $short_desc = trim($_POST['short_desc']);

    // Cập nhật sản phẩm
    $core->updateProduct($id, $name, $slug, $price, $category_id, $image, $short_desc);
    header('Location: index.php?page=product_list');
    exit;
}
?>

<div class="admin-main">
<h2>Sửa sản phẩm</h2>

<?php if (!empty($msg)): ?>
    <p style="color:red;"><?= htmlspecialchars($msg) ?></p>
<?php endif; ?>

<form method="POST">
    <label>Tên sản phẩm:</label>
    <input type="text" name="name" value="<?= htmlspecialchars($product['name']) ?>" required>

    <label>Giá:</label>
    <input type="number" name="price" value="<?= htmlspecialchars($product['price']) ?>" required>

    <label>Danh mục:</label>
    <select name="category_id" required>
        <?php foreach ($categories as $c): ?>
            <option value="<?= $c['id'] ?>" <?= ($c['id'] == $product['category_id']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($c['name']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label>Ảnh (tên file hoặc URL):</label>
    <input type="text" name="image" value="<?= htmlspecialchars($product['image']) ?>">

    <label>Mô tả ngắn:</label>
    <textarea name="short_desc"><?= htmlspecialchars($product['short_desc']) ?></textarea>

    <br>
    <button type="submit">Cập nhật</button>
</form>
</div>