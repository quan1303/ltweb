<?php
require_once(__DIR__ . '/../../lib/db.php');
require_once(__DIR__ . '/../../lib/coreFunction.php');

$db = new Database();
$core = new CoreFunction($db);

$categories = $core->getCategories(); 
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $slug = strtolower(str_replace(' ', '-', $name));
    $price = (int)$_POST['price'];
    $category_id = $_POST['category_id'];
    $image = trim($_POST['image']);
    $short_desc = trim($_POST['short_desc']);

    // Kiểm tra trùng sản phẩm
    if ($core->checkDuplicateProduct($name)) {
        $msg = "⚠️ Tên sản phẩm đã tồn tại!";
    } else {
        $core->addProduct($name, $slug, $price, $category_id, $image, $short_desc);
        header('Location: ../index.php?page=product_list');
        exit;
    }
}
?>
<div class="admin-main">
<h2>Thêm sản phẩm mới</h2>
<?php if ($msg): ?><p style="color:red"><?= htmlspecialchars($msg) ?></p><?php endif; ?>

<form method="POST">
    <label>Tên:</label>
    <input type="text" name="name" required><br>

    <label>Giá:</label>
    <input type="number" name="price" required><br>

    <label>Ảnh (đường dẫn):</label>
    <input type="text" name="image"><br>

    <label>Mô tả ngắn:</label>
    <textarea name="short_desc"></textarea><br>

    <label>Danh mục:</label>
    <select name="category_id" required>
        <?php foreach ($categories as $c): ?>
            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
        <?php endforeach; ?>
    </select><br>

    <button type="submit">Thêm sản phẩm</button>
</form>
</div>