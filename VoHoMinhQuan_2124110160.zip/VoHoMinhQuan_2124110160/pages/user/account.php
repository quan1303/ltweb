<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php?page=login');
    exit;
}

$user = $_SESSION['user'];
?>

<main class="container">
  <h2>Tài khoản của bạn</h2>
  <p><strong>Tên:</strong> <?= htmlspecialchars($user['username']) ?></p>
  <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
  <p><strong>Vai trò:</strong> <?= htmlspecialchars($user['role']) ?></p>
  <a href="index.php?page=logout" class="btn btn-danger">Đăng xuất</a>
</main>
