<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once(__DIR__ . '/../../lib/db.php');
require_once(__DIR__ . '/../../lib/coreFunction.php');
$db = new Database();
$core = new CoreFunction($db);

if (!isset($_SESSION['user'])) {
    header("Location: index.php?page=login");
    exit;
}

$orderId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$orderItems = $core->getOrderDetails($orderId);
?>

<main class="cart-container">
  <h2>Chi tiết đơn hàng #<?= $orderId ?></h2>

  <?php if (empty($orderItems)): ?>
    <p>Không tìm thấy đơn hàng.</p>
  <?php else: ?>
  <table class="cart-table">
    <tr>
      <th>Ảnh</th>
      <th>Tên sản phẩm</th>
      <th>Số lượng</th>
      <th>Giá</th>
      <th>Tổng</th>
    </tr>
    <?php $total = 0; foreach ($orderItems as $item): 
        $subtotal = $item['price'] * $item['quantity'];
        $total += $subtotal;
    ?>
    <tr>
      <td><img src="uploads/<?= htmlspecialchars($item['image']) ?>" width="70"></td>
      <td><?= htmlspecialchars($item['name']) ?></td>
      <td><?= $item['quantity'] ?></td>
      <td><?= number_format($item['price'], 0, ',', '.') ?> ₫</td>
      <td><?= number_format($subtotal, 0, ',', '.') ?> ₫</td>
    </tr>
    <?php endforeach; ?>
  </table>

  <div class="cart-total">
    <strong>Tổng cộng: <?= number_format($total, 0, ',', '.') ?> ₫</strong>
  </div>
  <a href="index.php?page=orders" class="btn btn-primary" style="margin-top:15px;">⬅ Quay lại danh sách</a>
  <?php endif; ?>
</main>
