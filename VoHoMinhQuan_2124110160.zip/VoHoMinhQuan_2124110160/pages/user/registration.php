<?php
if (session_status() === PHP_SESSION_NONE) session_start();

require_once(__DIR__ . '/../../lib/db.php');
require_once(__DIR__ . '/../../lib/coreFunction.php');
$db = new Database();
$core = new CoreFunction($db);

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if ($username && $email && $password) {
        $ok = $core->registerUser($username, $email, $password);
        if ($ok) {
            $message = '<div class="alert success">🎉 Đăng ký thành công! <a href="index.php?page=login">Đăng nhập ngay</a></div>';
        } else {
            $message = '<div class="alert error">⚠️ Email đã tồn tại!</div>';
        }
    } else {
        $message = '<div class="alert error">❗ Vui lòng nhập đủ thông tin!</div>';
    }
}
?>

<main class="auth-container">
  <div class="auth-box">
    <h2>Đăng ký tài khoản</h2>
    <?= $message ?>

    <form method="POST" class="auth-form">
      <div class="form-group">
        <label for="username">Họ và tên</label>
        <input type="text" id="username" name="username" class="form-control" required>
      </div>

      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" class="form-control" required>
      </div>

      <div class="form-group">
        <label for="password">Mật khẩu</label>
        <input type="password" id="password" name="password" class="form-control" required>
      </div>

      <button type="submit" class="btn btn-primary full">Tạo tài khoản</button>
    </form>

    <p class="auth-footer">
      Đã có tài khoản? <a href="index.php?page=login">Đăng nhập</a>
    </p>
  </div>
</main>
