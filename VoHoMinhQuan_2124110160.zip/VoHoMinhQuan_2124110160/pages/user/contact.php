<?php
if (session_status() === PHP_SESSION_NONE) session_start();

require_once(__DIR__ . '/../../lib/db.php');
require_once(__DIR__ . '/../../lib/coreFunction.php');
$db = new Database();
$core = new CoreFunction($db);

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $content = trim($_POST['content']);

    if ($name && $email && $content) {
        $ok = $core->addContact($name, $email, $content);
        if ($ok) {
            $message = '<div class="alert success">✅ Cảm ơn bạn! Chúng tôi đã nhận được liên hệ của bạn.</div>';
        } else {
            $message = '<div class="alert error">❌ Gửi liên hệ thất bại. Vui lòng thử lại sau.</div>';
        }
    } else {
        $message = '<div class="alert error">⚠️ Vui lòng nhập đủ thông tin!</div>';
    }
}
?>

<main class="auth-container">
  <div class="auth-box">
    <h2>Liên hệ với chúng tôi</h2>
    <?= $message ?>

    <form method="POST" class="auth-form">
      <div class="form-group">
        <label for="name">Họ và tên</label>
        <input type="text" id="name" name="name" class="form-control" required>
      </div>

      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" class="form-control" required>
      </div>

      <div class="form-group">
        <label for="content">Nội dung</label>
        <textarea id="content" name="content" class="form-control" rows="5" required></textarea>
      </div>

      <button type="submit" class="btn btn-primary full">Gửi liên hệ</button>
    </form>
  </div>
</main>
