<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once(__DIR__ . '/../../lib/db.php');
require_once(__DIR__ . '/../../lib/coreFunction.php');
$db = new Database();
$core = new CoreFunction($db);

if (!isset($_SESSION['user'])) {
    header("Location: index.php?page=login");
    exit;
}

$userId = $_SESSION['user']['id'];
$orders = $core->getOrdersByUser($userId);
?>

<main class="cart-container">
  <h2>Đơn hàng của tôi</h2>

  <?php if (empty($orders)): ?>
    <p>📦 Bạn chưa có đơn hàng nào.</p>
  <?php else: ?>
  <table class="cart-table">
    <tr>
      <th>ID đơn hàng</th>
      <th>Tổng tiền</th>
      <th>Ngày đặt</th>
      <th>Chi tiết</th>
    </tr>
    <?php foreach ($orders as $order): ?>
    <tr>
      <td>#<?= $order['id'] ?></td>
      <td><?= number_format($order['total'], 0, ',', '.') ?> ₫</td>
      <td><?= date('d/m/Y H:i', strtotime($order['created_at'])) ?></td>
      <td><a href="index.php?page=order_detail&id=<?= $order['id'] ?>" class="btn btn-primary">Xem</a></td>
    </tr>
    <?php endforeach; ?>
  </table>
  <?php endif; ?>
</main>
