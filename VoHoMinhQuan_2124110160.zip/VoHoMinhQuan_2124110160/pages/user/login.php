<?php
if (session_status() === PHP_SESSION_NONE) session_start();

require_once(__DIR__ . '/../../lib/db.php');
require_once(__DIR__ . '/../../lib/coreFunction.php');
$db = new Database();
$core = new CoreFunction($db);

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $user = $core->loginUser($email, $password);

    if ($user) {
        $_SESSION['user'] = $user;
        header('Location: index.php');
        exit;
    } else {
        $message = '<div class="alert error">⚠️ Sai thông tin đăng nhập!</div>';
    }
}
?>

<main class="auth-container">
  <div class="auth-box">
    <h2>Đăng nhập</h2>
    <?= $message ?>

    <form method="POST" class="auth-form">
      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" class="form-control" required>
      </div>

      <div class="form-group">
        <label for="password">Mật khẩu</label>
        <input type="password" id="password" name="password" class="form-control" required>
      </div>

      <button type="submit" class="btn btn-primary full">Đăng nhập</button>
    </form>

    <p class="auth-footer">
      Chưa có tài khoản? <a href="index.php?page=registration">Đăng ký ngay</a>
    </p>
  </div>
</main>
