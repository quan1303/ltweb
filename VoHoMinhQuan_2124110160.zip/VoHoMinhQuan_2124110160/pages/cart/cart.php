<?php
if (session_status() === PHP_SESSION_NONE) session_start();

require_once(__DIR__ . '/../../lib/db.php');
require_once(__DIR__ . '/../../lib/coreFunction.php');
$db = new Database();
$core = new CoreFunction($db);

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if (isset($_GET['add'])) {
    $id = (int)$_GET['add'];
    $product = $core->getProductById($id);
    if ($product) {
        $found = false;
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['id'] == $id) {
                $item['quantity']++;
                $found = true;
                break;
            }
        }
        if (!$found) {
            $_SESSION['cart'][] = [
                'id' => $product['id'],
                'name' => $product['name'],
                'price' => $product['price'],
                'image' => $product['image'],
                'quantity' => 1
            ];
        }
    }
    header("Location: index.php?page=cart");
    exit;
}

if (isset($_POST['update'])) {
    foreach ($_POST['qty'] as $id => $qty) {
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['id'] == $id) {
                $item['quantity'] = max(1, (int)$qty);
            }
        }
    }
}

if (isset($_GET['remove'])) {
    $_SESSION['cart'] = array_filter($_SESSION['cart'], function ($item) {
        return $item['id'] != $_GET['remove'];
    });
}

$message = '';
if (isset($_POST['checkout'])) {
    if (!isset($_SESSION['user'])) {
        header("Location: index.php?page=login");
        exit;
    }
    $userId = $_SESSION['user']['id'];
    $orderId = $core->createOrder($userId, $_SESSION['cart']);
    if ($orderId) {
        $_SESSION['cart'] = [];
        $message = '<div class="alert success">✅ Đặt hàng thành công!</div>';
    }
}
?>

<main class="cart-container">
  <h2>Giỏ hàng của bạn</h2>
  <?= $message ?>

  <?php if (empty($_SESSION['cart'])): ?>
    <p>🛒 Giỏ hàng trống!</p>
  <?php else: ?>
  <form method="POST">
    <table class="cart-table">
      <tr>
        <th>Ảnh</th>
        <th>Sản phẩm</th>
        <th>Giá</th>
        <th>Số lượng</th>
        <th>Tổng</th>
        <th></th>
      </tr>
      <?php $total = 0; foreach ($_SESSION['cart'] as $item): 
          $subtotal = $item['price'] * $item['quantity'];
          $total += $subtotal;
      ?>
      <tr>
        <td><img src="uploads/<?= htmlspecialchars($item['image']) ?>" width="70"></td>
        <td><?= htmlspecialchars($item['name']) ?></td>
        <td><?= number_format($item['price'], 0, ',', '.') ?> ₫</td>
        <td><input type="number" name="qty[<?= $item['id'] ?>]" value="<?= $item['quantity'] ?>" min="1"></td>
        <td><?= number_format($subtotal, 0, ',', '.') ?> ₫</td>
        <td><a href="index.php?page=cart&remove=<?= $item['id'] ?>" class="btn-remove">❌</a></td>
      </tr>
      <?php endforeach; ?>
    </table>

    <div class="cart-total">
      <strong>Tổng cộng: <?= number_format($total, 0, ',', '.') ?> ₫</strong>
    </div>

    <div class="cart-actions">
      <button type="submit" name="update" class="btn btn-primary">Cập nhật</button>
      <button type="submit" name="checkout" class="btn btn-success">Thanh toán</button>
    </div>
  </form>
  <?php endif; ?>
</main>
