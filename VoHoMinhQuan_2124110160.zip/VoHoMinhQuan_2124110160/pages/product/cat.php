<?php
require_once(__DIR__ . '/../../lib/db.php');
require_once(__DIR__ . '/../../lib/coreFunction.php');
$db = new Database();
$core = new CoreFunction($db);

// $slug = $_GET['slug'] ?? '';
// $category = $core->getCategoryBySlug($slug);
// $products = $core->getProductsByCategorySlug($slug);

// Lấy slug từ URL (index.php?page=cat&slug=ten-danh-muc)
$slug = $_GET['slug'] ?? '';
$products = [];
$category = null;

// Nếu có slug thì tìm danh mục tương ứng
if (!empty($slug)) {
    $category = $core->getCategoryBySlug($slug);
    if ($category) {
        $products = $core->getProductsByCategoryId($category['id']);
    }
}
?>

<!-- <main class="container">
  <h2><?= htmlspecialchars($category['name'] ?? 'Danh mục sản phẩm') ?></h2>

  <?php if (!empty($products)): ?>
    <div class="grid">
      <?php foreach ($products as $p): ?>
        <div class="product-card">
          <a href="index.php?page=product&sub=detail&id=<?= $p['id'] ?>">
            <img src="uploads/<?= htmlspecialchars($p['image']) ?>" alt="<?= htmlspecialchars($p['name']) ?>">
            <h3><?= htmlspecialchars($p['name']) ?></h3>
            <p><strong><?= number_format($p['price']) ?> đ</strong></p>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <p>Danh mục này chưa có sản phẩm hoặc slug không hợp lệ.</p>
  <?php endif; ?>
</main> -->

<!-- Giữ nguyên phần HTML hiển thị sản phẩm -->
<div class="container mt-4">
  <?php if ($category): ?>
    <h2 class="text-center mb-4">
      Sản phẩm thuộc danh mục: <?= htmlspecialchars($category['name']) ?>
    </h2>
  <?php endif; ?>

  <?php if (empty($products)): ?>
    <p class="text-center text-muted">Hiện chưa có sản phẩm nào trong danh mục này.</p>
  <?php else: ?>
    <div class="row">
      <?php foreach ($products as $p): ?>
        <div class="col-md-3 mb-4">
          <div class="card h-100 shadow-sm">
            <div class="card-body">
              <h5 class="card-title"><?= htmlspecialchars($p['name']) ?></h5>
              <p class="card-text"><?= number_format($p['price']) ?> VNĐ</p>
              <p class="text-muted small"><?= htmlspecialchars($p['short_desc']) ?></p>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>