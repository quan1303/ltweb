<?php
require_once(__DIR__ . '/../../lib/db.php');
require_once(__DIR__ . '/../../lib/coreFunction.php');
$db = new Database();
$core = new CoreFunction($db);
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$product = $core->getProductById($id);
?>

<main class="container">
  <?php if ($product): ?>
  <div class="product-detail">
    <img src="uploads/<?= htmlspecialchars($product['image']) ?>" alt="">
    <div class="info">
      <h2><?= htmlspecialchars($product['name']) ?></h2>
      <p><?= nl2br(htmlspecialchars($product['description'])) ?></p>
      <p><strong>Giá: </strong><?= number_format($product['price'], 0, ',', '.') ?> ₫</p>
      <a href="index.php?page=cart&add=<?= $product['id'] ?>" class="btn btn-primary">Thêm vào giỏ hàng</a>
    </div>
  </div>
  <?php else: ?>
  <p>Sản phẩm không tồn tại!</p>
  <?php endif; ?>
</main>
