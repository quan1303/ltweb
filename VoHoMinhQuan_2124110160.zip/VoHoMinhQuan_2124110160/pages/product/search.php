<?php
require_once 'lib/db.php';
require_once 'lib/coreFunction.php';

$db = new Database();
$core = new CoreFunction($db);

$keyword = $_GET['keyword'] ?? '';
$results = $core->searchProducts($keyword);
?>

<main class="container">
  <h2>Kết quả tìm kiếm cho: "<?= htmlspecialchars($keyword) ?>"</h2>
  <?php if ($results): ?>
    <div class="grid">
      <?php foreach ($results as $p): ?>
        <div class="product-card">
          <a href="index.php?page=detail&id=<?= $p['id'] ?>">
            <img src="asset/images/<?= htmlspecialchars($p['image']) ?>" alt="">
            <h3><?= htmlspecialchars($p['name']) ?></h3>
            <p><strong><?= number_format($p['price']) ?> đ</strong></p>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <p>Không tìm thấy sản phẩm nào phù hợp.</p>
  <?php endif; ?>
</main>
