<?php
require_once(__DIR__ . '/../../lib/db.php');
require_once(__DIR__ . '/../../lib/coreFunction.php');
$db = new Database();
$core = new CoreFunction($db);
$products = $core->getProducts(12);
?>

<main class="container">
  <h2>Tất cả sản phẩm</h2>
  <div class="product-grid">
    <?php foreach ($products as $p): ?>
      <div class="product-card">
        <img src="uploads/<?= htmlspecialchars($p['image']) ?>" alt="<?= htmlspecialchars($p['name']) ?>">
        <h3><?= htmlspecialchars($p['name']) ?></h3>
        <p><?= number_format($p['price'], 0, ',', '.') ?> ₫</p>
        <a href="index.php?page=product&sub=detail&id=<?= $p['id'] ?>" class="btn btn-primary">Xem chi tiết</a>
      </div>
    <?php endforeach; ?>
  </div>
</main>
