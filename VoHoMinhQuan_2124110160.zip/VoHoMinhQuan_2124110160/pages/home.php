<?php
require_once 'lib/db.php';
require_once 'lib/coreFunction.php';
$db = new Database();
$core = new CoreFunction($db);

// Lấy dữ liệu
$newProducts = $core->getProducts(4); // sản phẩm mới nhất
$promoProducts = $core->getPromoProducts(4); // sản phẩm khuyến mãi
$hotProducts = $core->getTopViewedProducts(4); // sản phẩm xem nhiều nhất
?>

<main class="container home-page">

  <!-- ==== BANNER ==== -->
  <div class="banner">
    <img src="asset/images/banner-main.png" alt="Laptop Cũ Giá Rẻ" class="banner-img">
  </div>

  <!-- ==== KHỐI SẢN PHẨM MỚI ==== -->
  <section class="product-section">
    <h2 class="section-title">🆕 Sản phẩm mới nhất</h2>
    <div class="product-grid">
      <?php foreach ($newProducts as $p): ?>
        <div class="product-card">
          <a href="index.php?page=detail&id=<?= $p['id'] ?>">
            <img src="asset/images/<?= htmlspecialchars($p['image']) ?>" alt="">
            <h3><?= htmlspecialchars($p['name']) ?></h3>
          </a>
          <p><?= number_format($p['price']) ?> đ</p>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- ==== KHỐI KHUYẾN MÃI ==== -->
  <section class="product-section">
    <h2 class="section-title">🔥 Sản phẩm khuyến mãi</h2>
    <div class="product-grid">
      <?php foreach ($promoProducts as $p): ?>
        <div class="product-card promo">
          <a href="index.php?page=detail&id=<?= $p['id'] ?>">
            <img src="asset/images/<?= htmlspecialchars($p['image']) ?>" alt="">
            <h3><?= htmlspecialchars($p['name']) ?></h3>
          </a>
          <p><?= number_format($p['price']) ?> đ</p>
          <span class="promo-badge">SALE</span>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- ==== KHỐI XEM NHIỀU ==== -->
  <section class="product-section">
    <h2 class="section-title">⭐ Sản phẩm nổi bật</h2>
    <div class="product-grid">
      <?php foreach ($hotProducts as $p): ?>
        <div class="product-card">
          <a href="index.php?page=detail&id=<?= $p['id'] ?>">
            <img src="asset/images/<?= htmlspecialchars($p['image']) ?>" alt="">
            <h3><?= htmlspecialchars($p['name']) ?></h3>
          </a>
          <p><?= number_format($p['price']) ?> đ</p>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

</main>
