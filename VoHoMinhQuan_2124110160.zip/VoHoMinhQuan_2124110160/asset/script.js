// JS nhỏ để xử lý menu mobile (nếu cần sau này)
document.querySelectorAll('.nav-item > a').forEach(item => {
  item.addEventListener('click', e => {
    const dropdown = item.nextElementSibling;
    if (dropdown) {
      e.preventDefault();
      dropdown.classList.toggle('show');
    }
  });
});
