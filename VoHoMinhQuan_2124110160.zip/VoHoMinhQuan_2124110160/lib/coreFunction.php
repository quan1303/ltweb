<?php
class CoreFunction {
    private $db;

    public function __construct($dbInstance) {
        $this->db = $dbInstance;
    }

    /* 🟩 LẤY DANH MỤC */
    public function getCategories() {
        try {
            $stmt = $this->db->pdo()->prepare("SELECT id, name, slug FROM category WHERE deleted = 0 ORDER BY name ASC");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("getCategories error: " . $e->getMessage());
            return [];
        }
    }

      // Lấy danh mục theo ID
    public function getCategoryById($id) {
        $sql = "SELECT * FROM category WHERE id = ?";
        $stmt = $this->db->pdo()->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Lấy danh mục theo slug
public function getCategoryBySlug($slug) {
    try {
        $stmt = $this->db->pdo()->prepare("SELECT * FROM category WHERE slug = ? AND deleted = 0 LIMIT 1");
        $stmt->execute([$slug]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("getCategoryBySlug error: " . $e->getMessage());
        return null;
    }
}


    /* 🟩 LẤY TOÀN BỘ SẢN PHẨM */
    public function getProducts($limit = 0) {
    try {
        $sql = "SELECT p.*, c.name AS category_name 
                FROM product p 
                LEFT JOIN category c ON p.category_id = c.id 
                WHERE p.deleted = 0 
                ORDER BY p.id DESC";
                
        if ($limit > 0) {
            $sql .= " LIMIT " . intval($limit);
        }

        $stmt = $this->db->pdo()->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log('getProducts error: ' . $e->getMessage());
        return [];
    }
}


    // Kiểm tra sản phẩm đã được đặt hàng chưa
public function isProductOrdered($product_id) {
    try {
        $sql = "SELECT COUNT(*) AS total FROM order_detail WHERE product_id = ?";
        $stmt = $this->db->pdo()->prepare($sql);
        $stmt->execute([$product_id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row && $row['total'] > 0;
    } catch (PDOException $e) {
        error_log("isProductOrdered error: " . $e->getMessage());
        return false;
    }
}


        public function getPromoProducts($limit = 4) {
    $sql = "SELECT * FROM product WHERE is_promo = 1 ORDER BY created_at DESC LIMIT ?";
    $stmt = $this->db->pdo()->prepare($sql);
    $stmt->bindValue(1, (int)$limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

public function getTopViewedProducts($limit = 4) {
    $sql = "SELECT * FROM product ORDER BY views DESC LIMIT ?";
    $stmt = $this->db->pdo()->prepare($sql);
    $stmt->bindValue(1, (int)$limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

   // Lấy sản phẩm theo ID
public function getProductById($id) {
    try {
        $sql = "SELECT * FROM product WHERE id = ? LIMIT 1";
        $stmt = $this->db->pdo()->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("getProductById error: " . $e->getMessage());
        return null;
    }
}

    /* 🟩 LẤY SẢN PHẨM THEO DANH MỤC SLUG */
    public function getProductsByCategorySlug($slug) {
        try {
            $stmt = $this->db->pdo()->prepare("
                SELECT p.*, c.name AS category_name 
                FROM product p 
                JOIN category c ON p.category_id = c.id 
                WHERE c.slug = ?
                ORDER BY p.id DESC
            ");
            $stmt->execute([$slug]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("getProductsByCategorySlug error: " . $e->getMessage());
            return [];
        }
    }

    // ========== CATEGORY MANAGEMENT ==========
    // Kiểm tra xem danh mục có sản phẩm nào hay không
public function hasProductInCategory($category_id) {
    $sql = "SELECT COUNT(*) AS total FROM product WHERE category_id = ?";
    $stmt = $this->db->pdo()->prepare($sql);
    $stmt->execute([$category_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['total'] > 0; // true nếu có sản phẩm, false nếu không
}

// Xóa mềm danh mục (đánh dấu deleted = 1)
public function softDeleteCategory($id) {
    $sql = "UPDATE category SET deleted = 1 WHERE id = ?";
    $stmt = $this->db->pdo()->prepare($sql);
    return $stmt->execute([$id]);
}


public function addCategory($name, $slug) {
    // Kiểm tra trùng
    $check = $this->db->pdo()->prepare("SELECT COUNT(*) FROM category WHERE name = ?");
    $check->execute([$name]);
    if ($check->fetchColumn() > 0) return false;

    $sql = "INSERT INTO category (name, slug, deleted) VALUES (?, ?, 0)";
    $stmt = $this->db->pdo()->prepare($sql);
    return $stmt->execute([$name, $slug]);
}

public function updateCategory($id, $name, $slug) {
    $sql = "UPDATE category SET name = ?, slug = ? WHERE id = ?";
    $stmt = $this->db->pdo()->prepare($sql);
    return $stmt->execute([$name, $slug, $id]);
}

// public function deleteCategory($id) {
//     // Xóa tạm (soft delete)
//     $sql = "UPDATE category SET deleted = 1 WHERE id = ?";
//     $stmt = $this->db->pdo()->prepare($sql);
//     return $stmt->execute([$id]);
// }

// Lấy danh sách danh mục đã xóa tạm
public function getDeletedCategories() {
    $sql = "SELECT * FROM category WHERE deleted = 1 ORDER BY id ASC";
    $stmt = $this->db->pdo()->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Phục hồi danh mục (đặt lại deleted = 0)
public function restoreCategory($id) {
    $sql = "UPDATE category SET deleted = 0 WHERE id = ?";
    $stmt = $this->db->pdo()->prepare($sql);
    return $stmt->execute([$id]);
}

// Xóa hẳn danh mục khỏi CSDL
public function deleteCategoryPermanently($id) {
    $sql = "DELETE FROM category WHERE id = ?";
    $stmt = $this->db->pdo()->prepare($sql);
    return $stmt->execute([$id]);
}

// ========== PRODUCT MANAGEMENT ==========

// Kiểm tra trùng tên sản phẩm
public function checkDuplicateProduct($name) {
    try {
        $sql = "SELECT id FROM product WHERE name = ? AND deleted = 0 LIMIT 1";
        $stmt = $this->db->pdo()->prepare($sql);
        $stmt->execute([$name]);
        return $stmt->fetch() ? true : false;
    } catch (PDOException $e) {
        error_log("checkDuplicateProduct error: " . $e->getMessage());
        return false;
    }
}

public function addProduct($name, $slug, $price, $category_id, $image, $short_desc) {
    try {
        $sql = "INSERT INTO product (name, slug, price, category_id, image, short_desc, deleted)
                VALUES (?, ?, ?, ?, ?, ?, 0)";
        $stmt = $this->db->pdo()->prepare($sql);
        return $stmt->execute([$name, $slug, $price, $category_id, $image, $short_desc]);
    } catch (PDOException $e) {
        error_log("addProduct error: " . $e->getMessage());
        return false;
    }
}

public function updateProduct($id, $name, $slug, $price, $category_id, $image, $short_desc) {
    try {
        $sql = "UPDATE product
                SET name=?, slug=?, price=?, category_id=?, image=?, short_desc=?
                WHERE id=?";
        $stmt = $this->db->pdo()->prepare($sql);
        return $stmt->execute([$name, $slug, $price, $category_id, $image, $short_desc, $id]);
    } catch (PDOException $e) {
        error_log("updateProduct error: " . $e->getMessage());
        return false;
    }
}

public function deleteProduct($id) {
    $sql = "DELETE FROM product WHERE id = ?";
    $stmt = $this->db->pdo()->prepare($sql);
    return $stmt->execute([$id]);
}





        /* 🟩 TÌM KIẾM SẢN PHẨM */
    public function searchProducts($keyword) {
        try {
            $kw = "%" . $keyword . "%";
            $stmt = $this->db->pdo()->prepare("SELECT * FROM product WHERE name LIKE ? OR short_desc LIKE ?");
            $stmt->execute([$kw, $kw]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("searchProducts error: " . $e->getMessage());
            return [];
        }
    }

    /* 🟩 THÊM LIÊN HỆ */
    public function addContact($name, $email, $message) {
        try {
            $stmt = $this->db->pdo()->prepare("INSERT INTO contact (name, email, message) VALUES (?, ?, ?)");
            return $stmt->execute([$name, $email, $message]);
        } catch (PDOException $e) {
            error_log("addContact error: " . $e->getMessage());
            return false;
        }
    }

    /* 🟩 ĐĂNG KÝ USER */
    public function registerUser($username, $email, $password) {
        try {
            $stmt = $this->db->pdo()->prepare("INSERT INTO user (username, email, password) VALUES (?, ?, ?)");
            return $stmt->execute([$username, $email, $password]);
        } catch (PDOException $e) {
            error_log("registerUser error: " . $e->getMessage());
            return false;
        }
    }

    /* 🟩 ĐĂNG NHẬP USER */
    public function loginUser($email, $password) {
        try {
            $stmt = $this->db->pdo()->prepare("SELECT * FROM user WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($user && $password === $user['password']) {
                return $user;
            }
            return null;
        } catch (PDOException $e) {
            error_log("loginUser error: " . $e->getMessage());
            return null;
        }
    }

    /* 🟩 TẠO ĐƠN HÀNG */
    public function createOrder($userId, $total, $cartItems) {
        try {
            $this->db->beginTransaction();

            $stmt = $this->db->pdo()->prepare("INSERT INTO orders (user_id, total) VALUES (?, ?)");
            $stmt->execute([$userId, $total]);
            $orderId = $this->db->lastInsertId();

            $stmtDetail = $this->db->prepare("INSERT INTO order_detail (order_id, product_id, qty, price) VALUES (?, ?, ?, ?)");
            foreach ($cartItems as $item) {
                $stmtDetail->execute([$orderId, $item['id'], $item['quantity'], $item['price']]);
            }

            $this->db->commit();
            return $orderId;
        } catch (PDOException $e) {
            $this->db->rollBack();
            error_log("createOrder error: " . $e->getMessage());
            return false;
        }
    }

    /* 🟩 LẤY ĐƠN HÀNG CỦA USER */
    public function getOrdersByUser($userId) {
        try {
            $stmt = $this->db->pdo()->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
            $stmt->execute([$userId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("getOrdersByUser error: " . $e->getMessage());
            return [];
        }
    }

    /* 🟩 CHI TIẾT ĐƠN HÀNG */
    public function getOrderDetails($orderId) {
        try {
            $stmt = $this->db->pdo()->prepare("
                SELECT od.*, p.name, p.image 
                FROM order_detail od 
                JOIN product p ON od.product_id = p.id 
                WHERE od.order_id = ?
            ");
            $stmt->execute([$orderId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("getOrderDetails error: " . $e->getMessage());
            return [];
        }
    }
}
?>
