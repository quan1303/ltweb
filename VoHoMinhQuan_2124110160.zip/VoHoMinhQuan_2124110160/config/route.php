<?php
// route.php
$page = $_GET['page'] ?? 'home';

switch ($page) {
    case 'home':
        $title = "Trang chủ";
        break;

    case 'product':
    case 'category':
    case 'detail':
        $title = "Sản phẩm";
        break;

    case 'cart':
        $title = "Giỏ hàng";
        break;

    case 'contact':
        $title = "Liên hệ";
        break;

    case 'login':
        $title = "Đăng nhập";
        break;

    case 'registration':
        $title = "Đăng ký";
        break;

    case 'logout':
        session_destroy();
        header("Location: index.php");
        exit();

    default:
        $title = "Laptop Cho Sinh Viên";
        break;
}
?>
