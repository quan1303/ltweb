<?php
session_start();
require_once __DIR__ . "/lib/db.php";
require_once __DIR__ . "/lib/coreFunction.php";
require_once __DIR__ . "/config/route.php";

$db = new Database();
$core = new CoreFunction($db);
if (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin' && !str_contains($_SERVER['REQUEST_URI'], 'admin')) {
    header('Location: admin/index.php');
    exit;
}
?>

<?php include __DIR__ . "/partial/header.php"; ?>

<main class="container">
<?php
$page = $_GET['page'] ?? 'home';
$subpage = $_GET['sub'] ?? ''; // dùng cho phân nhánh con (vd: product=detail,...)

// --- Xử lý route trang ---
switch ($page) {
    // ----------------- TRANG CHÍNH -----------------
    case 'home':
        include __DIR__ . "/pages/home.php";
        break;

    case 'contact':
        include __DIR__ . "/pages/user/contact.php";
        break;

    // ----------------- PRODUCT -----------------
    case 'product':
        switch ($subpage) {
            case 'cat':
                include __DIR__ . "/pages/product/cat.php";
                break;
            case 'detail':
                include __DIR__ . "/pages/product/detail.php";
                break;
            case 'search':
                include __DIR__ . "/pages/product/search.php";
                break;
            default:
                include __DIR__ . "/pages/product/product.php";
                break;
        }
        break;

    // ----------------- CART -----------------
    case 'cart':
        include __DIR__ . "/pages/cart/cart.php";
        break;

    // ----------------- USER -----------------
    case 'login':
        include __DIR__ . "/pages/user/login.php";
        break;

    case 'registration':
        include __DIR__ . "/pages/user/registration.php";
        break;

    case 'logout':
        include __DIR__ . "/pages/user/logout.php";
        break;

    case 'account':
        include __DIR__ . "/pages/user/account.php";
        break;

    // ----------------- MẶC ĐỊNH -----------------
    default:
        include __DIR__ . "/pages/home.php";
        break;
}
?>
</main>

<?php include __DIR__ . "/partial/footer.php"; ?>
