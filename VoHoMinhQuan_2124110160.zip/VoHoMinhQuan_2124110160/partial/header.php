<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Laptop Cũ Giá Rẻ</title>
  <link rel="stylesheet" href="asset/css/style.css">
  <script src="asset/js/script.js" defer></script>
</head>
<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$user = $_SESSION['user'] ?? null;
?>
<header class="site-header">
  <div class="top-header container">
    <div class="logo">
      <a href="index.php"><img src="asset/images/logo.png" alt="Logo"></a>
    </div>

    <form action="index.php?page=search" method="get" class="search-bar">
      <input type="hidden" name="page" value="search">
      <input type="text" name="keyword" placeholder="Tìm kiếm sản phẩm..." required>
      <button type="submit">🔍</button>
    </form>

    <div class="user-actions">
      <a href="index.php?page=cart">🛒 Giỏ hàng</a>
      <?php if ($user): ?>
        <a href="index.php?page=account"><?= htmlspecialchars($user['username']) ?></a> |
        <a href="index.php?page=logout">Đăng xuất</a>
      <?php else: ?>
        <a href="index.php?page=login">Đăng nhập</a> |
        <a href="index.php?page=registration">Đăng ký</a>
      <?php endif; ?>
    </div>
  </div>

  <?php include_once 'partial/nav.php'; ?>
</header>
