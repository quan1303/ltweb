<?php
require_once 'lib/db.php';
require_once 'lib/coreFunction.php';
$db = new Database();
$core = new CoreFunction($db);
$categories = $core->getCategories();
?>
<nav class="main-nav">
  <ul class="nav-menu container">
    <li><a href="index.php">🏠 Trang chủ</a></li>
    <li class="nav-item dropdown">
      <a href="#">💻 Danh mục</a>
      <div class="dropdown-content">
        <div class="dropdown-columns">
          <?php foreach ($categories as $cat): ?>
            <a href="index.php?page=cat&slug=<?= urlencode($cat['slug']) ?>">
              <?= htmlspecialchars($cat['name']) ?>
            </a>
          <?php endforeach; ?>
        </div>
      </div>
    </li>
    <li><a href="index.php?page=contact">📩 Liên hệ</a></li>
    <li><a href="index.php?page=about">ℹ️ Giới thiệu</a></li>
  </ul>
</nav>
