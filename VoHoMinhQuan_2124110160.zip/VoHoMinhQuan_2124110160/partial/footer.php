<footer class="site-footer">
  <div class="container footer-content">
    <div class="footer-col">
      <h4>Về chúng tôi</h4>
      <p>Website chuyên bán laptop cũ, chất lượng đảm bảo, giá phù hợp cho sinh viên.</p>
    </div>
    <div class="footer-col">
      <h4>Liên hệ</h4>
      <ul>
        <li>Email: support@laptopcugiare.vn</li>
        <li>Hotline: 0123 456 789</li>
        <li>Địa chỉ: 123 Nguyễn Văn Cừ, Q.5, TP.HCM</li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Theo dõi chúng tôi</h4>
      <ul>
        <li><a href="#">Facebook</a></li>
        <li><a href="#">YouTube</a></li>
      </ul>
    </div>
  </div>
</footer>
