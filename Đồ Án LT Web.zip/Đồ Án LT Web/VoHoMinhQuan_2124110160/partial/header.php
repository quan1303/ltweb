<?php
// partials/header.php
// Tự động tính base path (dùng khi project nằm trong subfolder trên localhost)
$basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
if ($basePath === '') $basePath = '/';
?>
<!doctype html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>MinhQuan</title>

  <!-- Link CSS: dùng basePath để tránh lỗi đường dẫn khi include -->
  <link rel="stylesheet" href="<?php echo $basePath; ?>/asset/css/style.css">
  <!-- favicon (nếu có) -->
  <link rel="icon" href="<?php echo $basePath; ?>/asset/images/favicon.ico" type="image/x-icon">
</head>
<body>
  <header class="site-header" style="background:#fff;border-bottom:1px solid #eee">
    <div class="container" style="display:flex;align-items:center;justify-content:space-between;padding:12px 0">
      <div class="logo" style="display:flex;align-items:center;gap:12px">
    <a href="<?php echo $basePath; ?>/index.php">
      <img src="<?php echo $basePath; ?>/asset/images/logo.png" alt="Logo" style="height:100px; display:block;">
    </a>
    <span class="slogan" style="font-size:20px;font-weight:700;color:#0b57a4;letter-spacing:0.5px">
      Laptop Cho Sinh Viên
    </span>
  </div>

      

      <div style="flex:1;padding:0 20px">
        <form action="<?php echo $basePath; ?>/index.php" method="get" class="search-form" style="display:flex;justify-content:flex-end;gap:8px">
          <input type="hidden" name="page" value="search">
          <input name="product" placeholder="Tìm sản phẩm..." style="padding:8px 10px;border:1px solid #ddd;border-radius:4px;min-width:260px">
          <button type="submit" style="padding:8px 12px;border:none;background:#ff6b00;color:#fff;border-radius:4px;cursor:pointer">Tìm</button>
        </form>
      </div>

      <div style="width:140px;text-align:right">
        <a href="<?php echo $basePath; ?>/index.php?page=registration" style="text-decoration:none;color:#0b57a4;font-weight:600">Đăng ký</a>
      </div>
    </div>
  </header>
