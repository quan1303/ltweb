<?php
// partials/footer.php
$basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
if ($basePath === '') $basePath = '/';
?>
<footer class="site-footer" style="background:#0b57a4;color:#fff;padding:24px 0;margin-top:30px">
  <div class="container" style="text-align:center">
    <p style="margin:0;font-weight:600">&copy; <?php echo date('Y'); ?> - MinhQuan - LapTop Cho Sinh Viên</p>
    <p style="margin:6px 0 0;font-size:13px">Địa chỉ: Hồ Chí Minh — Hotline: 0123 456 789 — Email: minhquan@gmail.com</p>
  </div>
</footer>

</body>
</html>
