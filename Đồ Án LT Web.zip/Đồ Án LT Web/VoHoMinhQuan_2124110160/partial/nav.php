<?php
// partials/nav.php (phiên bản đã sửa: không lặp menu, dropdown hoạt động đúng)
$basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
if ($basePath === '') $basePath = '/';

// Lấy danh mục từ DB nếu có, ngược lại dùng mặc định
$defaultCats = [
    ['id'=>1, 'name'=>'Laptop Gaming', 'slug'=>'laptop-gaming'],
    ['id'=>2, 'name'=>'Laptop Văn phòng', 'slug'=>'laptop-van-phong'],
    ['id'=>3, 'name'=>'Phụ kiện', 'slug'=>'phu-kien'],
    ['id'=>4, 'name'=>'Ultrabook / Mỏng nhẹ', 'slug'=>'ultrabook']
];
$catsToShow = $defaultCats;
if (isset($core) && method_exists($core, 'getCategories')) {
    $tmp = $core->getCategories();
    if (!empty($tmp)) $catsToShow = $tmp;
}
?>
<nav class="main-nav">
  <div class="container nav-inner">
    <ul class="nav-left">
      <li><a href="<?php echo $basePath; ?>/index.php">Trang chủ</a></li>

      <!-- Sản phẩm (drop-down) -->
      <li class="nav-item has-dropdown">
        <a href="<?php echo $basePath; ?>/index.php?page=product" class="nav-link">Sản phẩm <span class="caret">▾</span></a>
        <ul class="dropdown">
          <?php foreach ($catsToShow as $c):
              $idOrSlug = isset($c['id']) ? $c['id'] : urlencode($c['slug']);
              $url = $basePath . '/index.php?page=cat&id=' . $idOrSlug;
          ?>
            <li><a href="<?php echo $url; ?>"><?php echo htmlspecialchars($c['name']); ?></a></li>
          <?php endforeach; ?>
        </ul>
      </li>

      <li><a href="<?php echo $basePath; ?>/index.php?page=contact">Liên hệ</a></li>
      <li><a href="<?php echo $basePath; ?>/index.php?page=registration">Đăng ký</a></li>
    </ul>
  </div>
</nav>

<script>
/*
  JS nhỏ:
  - Trên mobile (<=800px) nếu người dùng click vào caret/đường dẫn Sản phẩm thì toggle dropdown (không redirect).
  - Nếu người dùng click đúng vào text link (muốn vào trang Sản phẩm), họ vẫn có thể giữ Ctrl+click / hoặc chúng ta có thể
    thay đổi behavior nếu muốn. Hiện xử lý chỉ khi click vào dấu caret hoặc khi viewport nhỏ.
*/
document.addEventListener('click', function(e) {
  var target = e.target;

  // tìm thẻ a.nav-link hoặc con của nó
  var navLink = target.closest && target.closest('.has-dropdown .nav-link');
  if (!navLink) {
    // nếu click ngoài, đóng mọi dropdown mobile
    document.querySelectorAll('.has-dropdown.open').forEach(function(el){ el.classList.remove('open'); });
    return;
  }

  // nếu ở mobile (kích thước nhỏ), toggle menu thay vì redirect
  if (window.innerWidth <= 800) {
    e.preventDefault(); // ngăn redirect
    var parent = navLink.closest('.has-dropdown');
    parent.classList.toggle('open');
  } else {
    // desktop: hover mới show, giữ hành vi link bình thường (đi đến product page nếu người dùng click)
  }
});
</script>
