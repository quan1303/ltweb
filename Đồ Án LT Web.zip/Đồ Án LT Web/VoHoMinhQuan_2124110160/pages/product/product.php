<?php
$products = $core->getProducts(0);
?>
<h1>Tất cả sản phẩm</h1>
<div class="product-grid">
  <?php foreach($products as $p): ?>
    <div class="card">
      <a href="index.php?page=detail&id=<?=$p['id']?>">
        <!-- <img src="uploads/<?=$p['image']?>" alt=""> -->
         <img src="asset/images/<?= rawurlencode($p['image']) ?>" alt="">
        <h3><?=htmlspecialchars($p['name'])?></h3>
        <p class="price"><?=number_format($p['price'])?> ₫</p>
      </a>
      <a class="btn" href="index.php?page=detail&id=<?=$p['id']?>">Chi tiết</a>
    </div>
  <?php endforeach; ?>
</div>
