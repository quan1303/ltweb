<?php
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$product = $core->getById('product', $id);
if(!$product){
  echo "<p>Sản phẩm không tồn tại.</p>";
  return;
}
$core->increaseViews($id);
?>
<div class="product-detail">
  <img src="asset/images/<?= rawurlencode($product['image']) ?>" alt="">
  <h1><?=$product['name']?></h1>
  <p class="price"><?=number_format($product['price'])?> ₫</p>
  <div class="desc"><?=$product['description']?></div>
</div>
