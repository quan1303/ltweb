<?php
$catId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$items = $core->getProductsByCategory($catId);
?>
<h2>Sản phẩm theo danh mục</h2>
<div class="product-grid">
  <?php foreach($items as $p): ?>
    <div class="card">
      <a href="index.php?page=detail&id=<?=$p['id']?>">
        <img src="asset/images/<?= rawurlencode($p['image']) ?>" alt="">
        <h3><?=$p['name']?></h3>
      </a>
    </div>
  <?php endforeach; ?>
</div>
