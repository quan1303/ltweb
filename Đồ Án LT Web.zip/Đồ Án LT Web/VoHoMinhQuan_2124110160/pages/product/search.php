<?php
$q = isset($_GET['product']) ? trim($_GET['product']) : '';
$results = $q ? $core->searchProducts($q) : [];
?>
<h2>Kết quả tìm kiếm cho "<?=htmlspecialchars($q)?>"</h2>
<div class="product-grid">
  <?php foreach($results as $r): ?>
    <div class="card">
      <a href="index.php?page=detail&id=<?=$r['id']?>">
        <img src="asset/images/<?= rawurlencode($p['image']) ?>" alt="">
        <h3><?=$r['name']?></h3>
        <p class="price"><?=number_format($r['price'])?> ₫</p>
      </a>
    </div>
  <?php endforeach; ?>
</div>
