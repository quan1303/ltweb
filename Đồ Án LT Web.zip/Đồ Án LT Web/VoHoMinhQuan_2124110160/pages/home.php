<?php
// pages/home.php
$newProducts = $core->getProducts(4); // 4 mới nhất
$promo = $core->getProducts(4, "is_promo = 1"); // khuyến mãi giả sử có cột is_promo
$topViews = $core->getProducts(4, "", "views DESC");
?>
<section class="home-grid">
  <h2>Sản phẩm mới</h2>
  <div class="product-grid">
    <?php foreach($newProducts as $p): ?>
      <div class="card">
        <a href="index.php?page=detail&id=<?=$p['id']?>">
          <img src="asset/images/<?= rawurlencode($p['image']) ?>" alt="">
          <h3><?=$p['name']?></h3>
          <p class="price"><?=number_format($p['price'])?> ₫</p>
        </a>
      </div>
    <?php endforeach;?>
  </div>

  <h2>Khuyến mãi</h2>
  <div class="product-grid">
    <?php foreach($promo as $p): ?>
      <div class="card">
        <a href="index.php?page=detail&id=<?=$p['id']?>">
           <img src="asset/images/<?= rawurlencode($p['image']) ?>" alt="">
          <h3><?=$p['name']?></h3>
          <p class="price"><?=number_format($p['price'])?> ₫</p>
        </a>
      </div>
    <?php endforeach;?>
  </div>

</section>
