<?php
$msg = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    require_once __DIR__ . '/../../lib/file.php';
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // validation cơ bản
    if(empty($username) || empty($email) || empty($_POST['password'])){
      $msg = "Vui lòng điền đầy đủ thông tin.";
    } else {
      $upload = new FileUpload($_FILES['avatar']);
      $res = $upload->upload();
      $avatar = isset($res['filename']) ? $res['filename'] : null;
      $ok = $core->addRecord('user', [
        'username' => $username,
        'email' => $email,
        'password' => $password,
        'avatar' => $avatar
      ]);
      if($ok) $msg = "Đăng ký thành công.";
      else $msg = "Lỗi lưu dữ liệu.";
    }
}
?>
<h2>Đăng ký</h2>
<?php if($msg) echo "<p class='msg'>$msg</p>"; ?>
<form method="post" enctype="multipart/form-data">
  <label>Username</label><input name="username" />
  <label>Email</label><input name="email" />
  <label>Password</label><input name="password" type="password" />
  <label>Avatar</label><input name="avatar" type="file" accept="image/*" />
  <button type="submit">Đăng ký</button>
</form>
