<h2>Liên hệ</h2>
<form action="index.php?page=contact" method="post">
  <label>Họ tên</label><input name="name" />
  <label>Email</label><input name="email" />
  <label>Nội dung</label><textarea name="message"></textarea>
  <button>Gửi</button>
</form>
