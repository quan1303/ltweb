// console.log("Lab01 script loaded");
// document.addEventListener("DOMContentLoaded", function() {
//   new Swiper(".banner", {
//     loop: true,
//     autoplay: { delay: 3000 },
//     pagination: { el: ".swiper-pagination", clickable: true },
//     navigation: { nextEl: ".swiper-button-next", prevEl: ".swiper-button-prev" }
//   });
// });
