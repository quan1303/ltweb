<?php
// lib/coreFunction.php
require_once __DIR__ . '/db.php';

class Core {
    protected $conn;

    public function __construct(){
        $this->conn = DB::getInstance()->getConnection();
    }

    public function getAll($table, $limit = null, $where = ''){
        $sql = "SELECT * FROM {$table} " . ($where ? "WHERE {$where}" : "") . " ORDER BY id DESC";
        if($limit) $sql .= " LIMIT {$limit}";
        $stmt = $this->conn->query($sql);
        return $stmt->fetchAll();
    }

    public function getById($table, $id){
        $stmt = $this->conn->prepare("SELECT * FROM {$table} WHERE id = :id LIMIT 1");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    public function query($sql, $params = []){
        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public function addRecord($table, $params = []){
        $cols = array_keys($params);
        $placeholders = array_map(function($c){ return ":{$c}"; }, $cols);
        $sql = "INSERT INTO {$table} (" . implode(',', $cols) . ") VALUES (" . implode(',', $placeholders) . ")";
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute($params);
    }

    // các hàm đặc thù cho product/category/search
    public function getProducts($limit = 0, $where = ''){
        $sql = "SELECT * FROM product ".($where ? "WHERE $where" : "")." ORDER BY created_at DESC";
        if($limit) $sql .= " LIMIT $limit";
        return $this->query($sql)->fetchAll();
    }

    public function increaseViews($id){
        $sql = "UPDATE product SET views = views + 1 WHERE id = :id";
        $this->query($sql, ['id'=>$id]);
    }

    public function searchProducts($keyword){
        $sql = "SELECT * FROM product WHERE name LIKE :k OR description LIKE :k";
        return $this->query($sql, ['k' => "%{$keyword}%"])->fetchAll();
    }

    public function getCategories(){
        return $this->query("SELECT * FROM category ORDER BY name")->fetchAll();
    }

    public function getProductsByCategory($catId){
        return $this->query("SELECT * FROM product WHERE category_id = :c", ['c' => $catId])->fetchAll();
    }
}
