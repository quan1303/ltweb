<?php
// lib/db.php
class DB {
    private static $instance = null;
    private $conn;

    private $host = '127.0.0.1';
    private $db   = 'minhquan';
    private $user = 'root';
    private $pass = '';
    private $charset = 'utf8mb4';

    private function __construct(){
        $dsn = "mysql:host={$this->host};dbname={$this->db};charset={$this->charset}";
        $opt = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ];
        $this->conn = new PDO($dsn, $this->user, $this->pass, $opt);
    }

    public static function getInstance(){
        if(self::$instance === null){
            self::$instance = new DB();
        }
        return self::$instance;
    }

    public function getConnection(){
        return $this->conn;
    }
}
