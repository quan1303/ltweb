<?php
// lib/file.php
class FileUpload {
    private $file;
    private $allowed = ['image/jpeg','image/png','image/gif'];
    private $maxSize = 2 * 1024 * 1024; // 2MB
    private $uploadDir = __DIR__ . '/../uploads/';

    public function __construct($file){
        $this->file = $file;
    }

    public function upload(){
        if(!$this->file || $this->file['error'] !== UPLOAD_ERR_OK) return ['error'=>'No file uploaded'];
        if(!in_array($this->file['type'], $this->allowed)) return ['error'=>'File type not allowed'];
        if($this->file['size'] > $this->maxSize) return ['error'=>'File too large'];
        $ext = pathinfo($this->file['name'], PATHINFO_EXTENSION);
        $name = time() . '_' . bin2hex(random_bytes(5)) . '.' . $ext;
        $dest = $this->uploadDir . $name;
        if(!move_uploaded_file($this->file['tmp_name'], $dest)) return ['error'=>'Upload failed'];
        return ['success' => true, 'filename' => $name];
    }
}
