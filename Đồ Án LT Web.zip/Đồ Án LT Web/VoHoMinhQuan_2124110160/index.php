<?php
// index.php
require_once 'lib/coreFunction.php';
$core = new Core();
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>MinhQuan</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="asset/css/style.css">
</head>
<body>
    <?php include 'partial/header.php'; ?>
    <?php include 'partial/nav.php'; ?>

    <main class="container">
        <?php require 'config/route.php'; ?>
    </main>

    <?php include 'partial/footer.php'; ?>
</body>
</html>
