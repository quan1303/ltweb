<?php
// config/route.php
$page = isset($_GET['page']) ? $_GET['page'] : 'home';
$allowed = [
    'home' => 'pages/home.php',
    'product' => 'pages/product/product.php',
    'detail' => 'pages/product/detail.php',
    'search' => 'pages/product/search.php',
    'cat' => 'pages/product/catProduct.php',
    'contact' => 'pages/user/contact.php',
    'registration' => 'pages/user/registration.php'
];

if(array_key_exists($page, $allowed)){
    include $allowed[$page];
} else {
    include 'pages/home.php';
}
