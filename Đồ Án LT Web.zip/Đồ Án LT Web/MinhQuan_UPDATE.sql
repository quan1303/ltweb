


DROP DATABASE IF EXISTS MinhQuan;
CREATE DATABASE MinhQuan CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE MinhQuan;

-- Bảng student (thông tin sinh viên)
DROP TABLE IF EXISTS student;
CREATE TABLE student (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(50) NOT NULL UNIQUE,
  full_name VARCHAR(150) NOT NULL,
  class VARCHAR(50) DEFAULT NULL,
  email VARCHAR(150) DEFAULT NULL,
  phone VARCHAR(50) DEFAULT NULL,
  note TEXT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Bảng category
DROP TABLE IF EXISTS category;
CREATE TABLE category (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  slug VARCHAR(200) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Bảng product
DROP TABLE IF EXISTS product;
CREATE TABLE product (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(300) DEFAULT NULL,
  short_desc VARCHAR(512) DEFAULT NULL,
  description TEXT,
  price BIGINT DEFAULT 0,
  image VARCHAR(255) DEFAULT NULL,
  category_id INT DEFAULT NULL,
  views INT DEFAULT 0,
  is_promo TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES category(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Bảng user
DROP TABLE IF EXISTS user;
CREATE TABLE user (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  avatar VARCHAR(255) DEFAULT NULL,
  role VARCHAR(50) DEFAULT 'student',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Bảng contact
DROP TABLE IF EXISTS contact;
CREATE TABLE contact (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL,
  message TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sinh viên mẫu
INSERT INTO student (student_id, full_name, class, email, phone, note) VALUES
('B2124110160', 'MinhQuan', 'Lop E', 'minhquan@gmail.com', '0123456789', 'Đồ án lập trình web');

-- Tài khoản user mẫu
INSERT INTO user (username, email, password, avatar, role) VALUES
('minhquan','minhquan@gmail.com','hoaNhaiThomPhuc','avatar_student.png','student');

-- Danh mục laptop
INSERT INTO category (name, slug) VALUES
('Laptop Gaming', 'laptop-gaming'),
('Ultrabook / Mỏng nhẹ', 'ultrabook'),
('Laptop Văn phòng', 'laptop-van-phong'),
('Phụ kiện', 'phu-kien');

-- Dữ liệu sản phẩm
INSERT INTO product (name, slug, short_desc, description, price, image, category_id, views, is_promo) VALUES
('Lenovo Legion 5 Pro', 'lenovo-legion-5-pro', 'AMD Ryzen 7 • RTX 3070 • 16GB RAM • 512GB SSD', 'Lenovo Legion 5 Pro - cấu hình mạnh cho gaming và làm việc. Màn 16\" QHD 165Hz. Hệ thống tản nhiệt tốt.', 34990000, 'lenovo_legion_5_pro.jpg', 1, 120, 1),
('ASUS ROG Strix G15', 'asus-rog-strix-g15', 'Intel i7 • RTX 4060 • 16GB RAM • 1TB SSD', 'ASUS ROG Strix G15 - hiệu năng cao, bàn phím RGB, màn 144Hz.', 31990000, 'asus_rog_strix_g15.jpg', 1, 95, 1),
('MSI Katana GF66', 'msi-katana-gf66', 'Intel i5 • RTX 3050 • 8GB RAM • 512GB SSD', 'MSI Katana GF66 - lựa chọn tốt cho game và đồ họa nhẹ.', 17990000, 'msi_katana_gf66.jpg', 1, 60, 0),
('Dell XPS 13 9310', 'dell-xps-13-9310', 'Intel i7 • 16GB RAM • 512GB SSD • Màn 13.4\"', 'Dell XPS 13 - mỏng nhẹ, thiết kế cao cấp, pin tốt cho văn phòng.', 38990000, 'dell_xps_13_9310.jpg', 2, 80, 0),
('MacBook Air M2 2023', 'macbook-air-m2-2023', 'Apple M2 • 8GB RAM • 256GB SSD', 'MacBook Air M2 - nhẹ, mượt, phù hợp học tập & văn phòng.', 32990000, 'macbook_air_m2.jpg', 2, 210, 1),
('HP Pavilion 15', 'hp-pavilion-15', 'Intel i5 • 8GB RAM • 512GB SSD', 'HP Pavilion - laptop văn phòng phổ thông, bền, giá hợp lý.', 15990000, 'hp_pavilion_15.jpg', 3, 35, 0),
('Acer Aspire 5', 'acer-aspire-5', 'Intel i3 • 8GB RAM • 256GB SSD', 'Acer Aspire 5 - phù hợp học tập, sinh viên.', 10990000, 'acer_aspire_5.jpg', 3, 20, 0),
('Chuột Logitech G502', 'chuot-logitech-g502', 'Chuột chơi game có dây • DPI cao', 'Chuột Logitech G502 - tối ưu cho gamer với nhiều nút lập trình.', 1290000, 'logitech_g502.jpg', 4, 45, 0),
('Tai nghe Sony WH-1000XM5', 'sony-wh-1000xm5', 'Tai nghe chống ồn, âm thanh cao cấp', 'Sony WH-1000XM5 - chống ồn, pin lâu, âm thanh chi tiết.', 7490000, 'sony_wh1000xm5.jpg', 4, 55, 1);

-- Indexes
CREATE INDEX idx_product_name ON product(name);
CREATE INDEX idx_category_name ON category(name);
