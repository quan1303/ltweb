-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 28, 2025 at 06:33 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phuctan`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `parent` tinyint(4) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `trash` tinyint(1) NOT NULL DEFAULT 0,
  `creater_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category_name`, `slug`, `parent`, `status`, `trash`, `creater_at`) VALUES
(1, 'HG Gundam', 'HG-Gundam', 1, 1, 0, '2025-09-15 11:06:29'),
(2, 'Transformers', 'Transformers', 2, 1, 0, '2025-09-09 11:10:11'),
(3, 'Umamusume', 'Umamusume\r\n', 3, 1, 0, '2025-09-15 11:12:51'),
(4, 'Figure Mihoyo', 'Figure-Mihoyo', 4, 1, 0, '2025-09-15 11:12:51'),
(5, 'Wuthering waves', '\nwuthering-waves', 5, 1, 0, '2025-09-15 11:14:50');

-- --------------------------------------------------------

--
-- Table structure for table `contsact`
--

CREATE TABLE `contsact` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `creater_at` bigint(20) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `oder_code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `order_date` datetime NOT NULL DEFAULT current_timestamp(),
  `address` varchar(255) DEFAULT NULL,
  `total` bigint(20) NOT NULL DEFAULT 0,
  `delivery` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `Order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `trash` tinyint(1) DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metakey` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadesc` varchar(256) DEFAULT NULL,
  `created_at` bigint(20) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `trash` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `post_image`
--

CREATE TABLE `post_image` (
  `id` int(11) NOT NULL,
  `post_id` int(255) NOT NULL,
  `image` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `trash` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cat_id` int(11) NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` float NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metakey` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadesc` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_on_sale` tinyint(1) DEFAULT 0,
  `sale_price` double NOT NULL DEFAULT 0,
  `created_at` date DEFAULT NULL,
  `trash` tinyint(1) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `views` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_name`, `slug`, `cat_id`, `image`, `price`, `description`, `metakey`, `metadesc`, `is_on_sale`, `sale_price`, `created_at`, `trash`, `status`, `views`) VALUES
(0, 'HG Babatos', 'HG-babatos', 1, 'HG_babatos.jpg', 150, 'Mô hình HG Babatos tỉ lệ 1/144', NULL, NULL, 1, 0, '2025-09-02', 0, 1, 0),
(1, 'HG Exia', 'HG-Exia', 1, 'exia.jpg', 350, 'Mô hình HG Exia tỉ lệ 1/144', NULL, NULL, 0, 0, '2025-09-02', 0, 1, 0),
(3, 'HG Unicorn', 'HG-Unicorn', 1, 'unicorn.jpg', 499, 'Mô hình HG Unicorn tỉ lệ 1/144', NULL, NULL, 0, 0, '2025-09-15', 0, 1, 0),
(4, 'HG QuuuuuuuX', 'HG-QuuuuuuuX', 1, 'HG-QuuuuuuuX.jpg', 580, 'Mô hình HG Unicorn tỉ lệ 1/144', NULL, NULL, 0, 0, '2025-08-04', 0, 1, 0),
(5, 'HG Aerial', 'HG-Aerial', 1, 'HG-Aerial.jpg', 599, 'Mô hình HG Aerial tie lệ 1/144', NULL, NULL, 0, 0, '2025-09-15', 0, 1, 0),
(6, 'HG Sengoku Astray', 'HG-Sengoku-Astray', 1, 'HG-Sengoku-Astray.jpg', 580, 'Mô hình HG Sengoku Astray tỉ lệ 1/144', NULL, NULL, 0, 0, '2025-08-04', 0, 1, 0),
(7, 'Optimus Prime', 'Optimus-Prime', 2, 'op.jpg', 3500, 'Mô hình Optimus Prime', NULL, NULL, 0, 0, NULL, 0, 1, 0),
(8, 'Megatron', 'Megatron', 2, 'mega.jpg', 2500, 'Mô hình Megatron', NULL, NULL, 0, 0, '2025-09-01', 0, 1, 0),
(9, 'Bumblebee', 'Bumblebee', 2, 'bee.jpg', 1500, 'Mô hình Bumblebee', NULL, NULL, 0, 0, '2025-07-06', 0, 1, 0),
(10, 'Satono Diamond', 'Satono-Diamond', 3, 'satono.jpg', 480, 'Mô hình mã nương Satono Diamond', NULL, NULL, 0, 0, NULL, 0, 1, 0),
(11, 'Tokai Teio ', 'Tokai-teio', 3, 'teio.jpg', 1250, 'Mô hình mã nương Tô khải Tèo (Tokai Teio)', NULL, NULL, 0, 0, '2025-08-25', 0, 1, 0),
(12, 'Special Week', 'Special-Week', 3, 'week.jpg', 880, 'Mô hình mã nương Tuần Đặc Biệt (Special Week)', NULL, NULL, 0, 0, '2025-09-10', 0, 1, 0),
(13, 'Mejiro McQueen', 'Mejiro-McQueen', 3, 'mcqeen.jpg', 999, 'Mô hình mã nương Mặc Quyên (Mejiro McQueen)', NULL, NULL, 0, 0, '2025-08-25', 0, 1, 0),
(14, 'Elysia Herrcher of Human Ego', 'Elysia-Herrcher-of-Human-Ego', 4, 'h2o.jpg', 5300, 'Mô hình Elysia Herrcher of Human Ego Honkai Impact tỷ lệ 1/4', NULL, NULL, 0, 0, '2025-09-09', 0, 1, 0),
(15, 'Raiden Mei Herrscher of Thunder', 'Raiden-Mei-Herrscher-of-Thunder', 4, 'hot.jpg', 6000, 'Mô hình Raiden Mei Herrscher of Thunder Honkai Impact tỷ lệ 1/8 ', NULL, NULL, 0, 0, '2025-09-01', 0, 1, 0),
(16, 'Changli', 'Changli', 5, 'changli.jpg', 5000, 'Standee in theo yêu cầu', NULL, NULL, 0, 0, NULL, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `image` varchar(256) DEFAULT NULL,
  `sort_order` tinyint(4) DEFAULT NULL,
  `position` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthday` date DEFAULT NULL,
  `created_at` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `trash` tinyint(1) DEFAULT 0,
  `role` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`Order_id`,`product_id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_image`
--
ALTER TABLE `post_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `post_image`
--
ALTER TABLE `post_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
pphuctanhuctan