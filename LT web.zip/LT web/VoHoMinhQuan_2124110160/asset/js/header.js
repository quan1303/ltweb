// ========== HEADER INTERACTIVITY ==========
// Đảm bảo DOM đã được tải hoàn toàn trước khi thực thi script
document.addEventListener('DOMContentLoaded', function() {
  // Lấy các phần tử DOM cần tương tác
  const mobileMenuToggle = document.getElementById('mobileMenuToggle');
  const navbar = document.getElementById('navbar');
  const navLinks = document.querySelectorAll('.nav-link');
  const currentLocation = window.location.pathname;
  
  // ========== MOBILE MENU TOGGLE ==========
  // Xử lý sự kiện click vào nút menu mobile
  if (mobileMenuToggle) {
    mobileMenuToggle.addEventListener('click', function() {
      // Toggle class active cho nút menu và navbar
      this.classList.toggle('active');
      navbar.classList.toggle('active');
      
      // Ngăn chặn cuộn trang khi menu mobile mở
      document.body.style.overflow = navbar.classList.contains('active') ? 'hidden' : 'auto';
    });
  }
  
  // ========== ACTIVE LINK HIGHLIGHTING ==========
  // Tự động đánh dấu mục menu tương ứng với trang hiện tại
  navLinks.forEach(link => {
    const linkPath = link.getAttribute('href');
    
    // So sánh đường dẫn để xác định trang hiện tại
    if (currentLocation === linkPath || 
        (currentLocation.includes(linkPath) && linkPath !== '/')) {
      link.classList.add('active');
    }
    
    // Đóng menu mobile khi click vào một mục menu
    link.addEventListener('click', function() {
      if (navbar.classList.contains('active')) {
        navbar.classList.remove('active');
        mobileMenuToggle.classList.remove('active');
        document.body.style.overflow = 'auto';
      }
    });
  });
  
  // ========== CLOSE MENU WHEN CLICKING OUTSIDE ==========
  // Đóng menu mobile khi click ra ngoài vùng menu
  document.addEventListener('click', function(event) {
    const isClickInsideNavbar = navbar.contains(event.target);
    const isClickOnToggle = mobileMenuToggle.contains(event.target);
    
    if (!isClickInsideNavbar && !isClickOnToggle && navbar.classList.contains('active')) {
      navbar.classList.remove('active');
      mobileMenuToggle.classList.remove('active');
      document.body.style.overflow = 'auto';
    }
  });
  
  // ========== STICKY HEADER ON SCROLL ==========
  // Thêm hiệu ứng cho header khi cuộn trang
  let lastScrollTop = 0;
  const header = document.querySelector('.main-header');
  
  window.addEventListener('scroll', function() {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
    // Ẩn header khi cuộn xuống, hiện khi cuộn lên
    if (scrollTop > lastScrollTop && scrollTop > 100) {
      header.style.transform = 'translateY(-100%)';
    } else {
      header.style.transform = 'translateY(0)';
    }
    
    lastScrollTop = scrollTop;
  }, { passive: true });
});