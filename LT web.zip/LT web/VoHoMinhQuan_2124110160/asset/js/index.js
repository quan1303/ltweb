// Hiện popup khi ấn "Chi tiết"
function openPopup(title, price, image, desc) {
  // Đặt thông tin vào popup
  document.getElementById("popup-title").innerText = title;
  document.getElementById("popup-price").innerText = price + " VND";
  document.getElementById("popup-desc").innerText = desc;

  // Chú ý đường dẫn ảnh phải khớp với PHP (đang nằm trong asset/image)
  document.getElementById("popup-image").src = "./asset/image/" + image;

  // Hiện popup
  document.getElementById("popup").style.display = "flex";
}

// Đóng popup
function closePopup() {
  document.getElementById("popup").style.display = "none";
}
