  <!--css-->
  <link rel="stylesheet" href="asset/css/nav.css">

  <!-- Navigation Menu -->
<form method="GET" action="http://localhost/VoHoMinhQuan_2124110160/index.php">
    <input type="hidden" name="page" value="search">
    <input type="text" name="product_search" placeholder="Nhập tên sản phẩm..." required>
    <button type="submit">Tìm</button>
</form>


  <a href="http://localhost/VoHoMinhQuan_2124110160/index.php" class="nav-link active">HOME</a>
  <a href="http://localhost/VoHoMinhQuan_2124110160/index.php?page=product" class="nav-link">Sản Phẩm</a>
  <a href="#" class="nav-link cart-link">
    🛒 Giỏ hàng <span class="cart-badge">2</span>
  </a>
  <a href="#" class="nav-link">Đăng nhập</a>
  <a href="http://localhost/VoHoMinhQuan_2124110160/index.php?page=contact" class="nav-link">Đăng Ký</a>
  <a href="http://localhost/VoHoMinhQuan_2124110160/index.php?page=registration" class="nav-link">Liên Hệ</a>
</nav>
