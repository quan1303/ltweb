<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RirinShop</title>
  <!-- CSS chung -->
  <link rel="stylesheet" href="asset/css/header.css">
  <link rel="stylesheet" href="asset/css/footer.css">
  <link rel="stylesheet" href="asset/css/styleindex.css">
  <link rel="stylesheet" href="asset/css/stylecontact.css">
  <link rel="stylesheet" href="asset/css/styleregstration.css">
</head>
<body>
  <!-- Header Section -->
<!-- Header Section -->
<header class="main-header">
  <div class="header-container">
    <!-- Logo -->
    <a href="#" class="logo">
      RirinShop 
    </a>

    <!-- Gọi nav.php -->
    <?php include("nav.php"); ?>

    <!-- Nút menu mobile -->
    <button class="mobile-menu-toggle" id="mobileMenuToggle">
      <span></span>
      <span></span>
      <span></span>
    </button>
  </div>
</header>

  <!-- Main content -->
  <main>
    <!-- Nội dung chính của trang -->
  </main>
  
  <!-- Script cho header -->
  <script src="asset/js/header.js"></script>
