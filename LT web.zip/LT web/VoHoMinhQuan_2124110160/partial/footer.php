
<footer>
  <div class="footer-container">
    <!-- Section 1: About -->
    <div class="footer-section">
      <h4>YuRirinShop</h4>
      <p></p>
      <ul class="socials">
        <li><a href="#"><img src="/asset/icons/facebook.svg" alt="Facebook"></a></li>
        <li><a href="#"><img src="/asset/icons/instagram.svg" alt="Instagram"></a></li>
        <li><a href="https://www.tiktok.com/@kianalovemei"><img src="/asset/icons/tiktok.svg" alt="Tiktok"></a></li>
      </ul>
    </div>
    
    <!-- Section 2: Quick Links -->
    <div class="footer-section">
      <h4>Liên kết nhanh</h4>
      <ul class="footer-links">
        <li><a href="/index.php">Trang chủ</a></li>
        <li><a href="#">Sản phẩm</a></li>
        <li><a href="#">Giỏ hàng</a></li>
        <li><a href="/pages/user/registration.php">Đăng ký</a></li>
        <li><a href="/pages/user/contact.php">Liên hệ</a></li>
      </ul>
    </div>
    
    <!-- Section 3: Contact Info -->
    <div class="footer-section">
      <h4>Thông tin liên hệ</h4>
      <p><strong>Địa chỉ:</strong> 123 Đường ABC, Quận XYZ, TP. Hồ Chí Minh</p>
      <p><strong>Điện thoại:</strong> (00000000)</p>
      <p><strong>Email:</strong> info@yuririnshop.com</p>
      <p><strong>Giờ làm việc:</strong> 8:00 - 22:00 (Thứ 2 - Chủ nhật)</p>
    </div>
  </div>
  
  <div class="footer-bottom">
    <p>© 2025 YuRirinShop. nơi giúp bạn thỏa mãn cơn nghiện nhựa.</p>
  </div>
</footer>
