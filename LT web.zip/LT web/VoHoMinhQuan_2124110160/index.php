<!--HEADER-->
<?php
    require("partial/header.php");
    

?>
<!--NAV-->



<!------------------------------->

<!--Home-->

<?php
 require("config/route.php");
 
 $page = isset($_GET['page']) ? $_GET['page'] : "";
 
 foreach ($route as $r => $val) {
     if ($r == $page) {
         $file = __DIR__ . '/' . $val;
         if (file_exists($file)) {
             require $file;
         } else {
             echo "File không tồn tại: $file";
         }
     }
 }
?>


  <!-- Danh sách sản phẩm  product -->




  <!------------------------------------------------------->
<!--FOOTER-->
<?php
    require("partial/footer.php");
?>






<!-- Link JS -->
<script src="asset/js/index.js"></script>




