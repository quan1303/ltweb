<!--HEADER-->

<!-- thông tin liên hệ -->
<link rel="stylesheet" href="../../asset/css/stylecontact.css">



<h2>ĐIỀN THÔNG TIN LIÊN HỆ</h2>
<form action ="" method="post" class=contact-form>
    <div>
        <label>Mã khách hàng</label>
        <input type ="text" name ="ma_kh" placeholder ="Mã KH">
    </div>
     <div>
        <label>Họ Tên</label>
        <input type ="text" name ="ho_ten" placeholder ="Họ Tên">
    </div> 
    <div>
        <label>Địa chỉ</label>
        <input type ="text" name ="addres" placeholder ="Địa chỉ">
    </div> 
    <div>
        <label>Email</label>
        <input type ="email" name ="email" placeholder ="Email">
    </div> 
    <div>
        <label>Nội Dung Liên Hệ</label>
        <textarea name ="noi_dung" row ="4" placeholder ="Nhập nội dung "></textarea>
    </div>
    <div>
        <button style = "submit">Lấy Thông Tin</button>
    </div>
    <a href="http://localhost/VoHoMinhQuan_2124110160/index.php?page=home">Home</a>

</form>
