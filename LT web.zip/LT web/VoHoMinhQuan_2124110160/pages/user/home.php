<?php 
require("config/database.php"); // Kết nối CSDL
require("lib/coreFunction.php"); // Import class coreFunction để thao tác với DB
$core = new coreFunction(); // Khởi tạo đối tượng coreFunction

// DESC = giảm dần (mới nhất trước), LIMIT 4 = chỉ lấy 4 sản phẩm
$sql = "SELECT * FROM product ORDER BY created_at DESC LIMIT 4"; 
$result = $core->conn->query($sql);
$sql_top = "SELECT * FROM product ORDER BY views DESC LIMIT 5";
$result_top = $core->conn->query($sql_top);
?>
<!--INDEX-->
<!-- Banner đầu trang -->
<section class="banner">
  <div class="banner-content">
    <h2>Đừng bao giờ chơi game gacha</h2>
    <p>Dưới 100% cũng chỉ là 50/50</p>
    <!-- Nút dẫn tới trang danh sách sản phẩm -->
    <a href="index.php?page=product" class="btn-banner">Xem ngay</a>
  </div>
</section>

<section class="products">
  <!-- Danh mục sản phẩm (hardcode, bạn tự viết tay) -->
  <h2 class="section-title">Các loại sản phẩm</h2>
  <div class="product-list">
    <!-- Card danh mục 1 -->
    <div class="product-card">
      <img src="./asset/image/HG_babatos.jpg" alt="Sản phẩm 1">
      <h3>Gundam</h3>
      <p class="desc">Figure Bandai chính hãng</p>
      <!-- Khi click → load trang product với cat_id=1 -->
      <a href="index.php?page=product&cat_id=1" class="btn-buy">Xem tất cả sản phẩm</a>
    </div>

    <!-- Card danh mục 2 -->
    <div class="product-card">
      <img src="./asset/image/micho.jpg" alt="Sản phẩm 2">
      <h3>Figure Hoyo</h3>
      <p class="desc">Figure MiHoYo</p>
      <a href="index.php?page=product&cat_id=4" class="btn-buy">Xem tất cả sản phẩm</a>
    </div>

    <!-- Card danh mục 3 -->
    <div class="product-card">
      <img src="./asset/image/luna.png" alt="Sản phẩm 3">
      <h3>Transformer</h3>
      <p class="desc">Figure Transformer</p>
      <a href="index.php?page=product&cat_id=2" class="btn-buy">Xem tất cả sản phẩm</a>
    </div>

    <!-- Card danh mục 4 -->
    <div class="product-card">
      <img src="./asset/image/lucia.webp" alt="Sản phẩm 4">
      <h3>Uma Musume</h3>
      <p class="desc">Figure Uma Musume</p>
      <a href="index.php?page=product&cat_id=3" class="btn-buy">Xem tất cả sản phẩm</a>
    </div>

    <!-- Card danh mục 5 -->
    <div class="product-card">
      <img src="./asset/image/qu.jpg_large.jpg" alt="Sản phẩm 5">
      <h3>Wuwa</h3>
      <p class="desc">Figure Wuthering wave</p>
      <a href="index.php?page=product&cat_id=5" class="btn-buy">Xem tất cả sản phẩm</a>
    </div>
  </div> <!-- đóng product-list -->
  
  <!-- Sản phẩm mới -->
  <h2 class="section-title">Các sản phẩm mới</h2>
  <div class="product-list">
    <?php if($result && $result->num_rows > 0): ?>
      <?php while($value = $result->fetch_assoc()): ?>
        <div class="product-card">
          <!-- Hình ảnh sản phẩm -->
          <img src="asset/image/<?= $value['image'] ?>" alt="<?= $value['product_name'] ?>">
          <!-- Tên sản phẩm -->
          <h3><?= $value['product_name'] ?></h3>
          <!-- Giá (format số thành 1.000.000) -->
          <p class="price"><?= number_format($value['price'],0,",",".") ?> VND</p>
          <!-- Nút mua ngay (thêm vào giỏ hàng) -->
          <a href="pages/cart/add.php?slug=<?= $value['slug'] ?>" class="btn-buy">Mua ngay</a>
          <!-- Nút chi tiết -->
          <a href="index.php?page=productdetail&slug=<?= $value['slug'] ?>" class="btn-detail">Chi tiết</a>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p>Chưa có sản phẩm trong database.</p>
    <?php endif; ?>
  </div>
  <!-- Hiển thị sản phẩm có lượt xem cao nhất -->
<h2 class="section-title">Top 5 sản phẩm có lượt xem cao nhất</h2>
<div class="product-list">
  <?php if($result_top && $result_top->num_rows > 0): ?>
    <?php while($value = $result_top->fetch_assoc()): ?>
      <div class="product-card">
        <img src="asset/image/<?= $value['image'] ?>" alt="<?= $value['product_name'] ?>">
        <h3><?= $value['product_name'] ?></h3>
        <p class="price"><?= number_format($value['price'],0,",",".") ?> VND</p>
        <a href="pages/cart/add.php?slug=<?= $value['slug'] ?>" class="btn-buy">Mua ngay</a>
        <a href="index.php?page=productdetail&slug=<?= $value['slug'] ?>" class="btn-detail">Chi tiết</a>
      </div>
    <?php endwhile; ?>
  <?php else: ?>
    <p>Không có sản phẩm phổ biến.</p>
  <?php endif; ?>
</div>
</section>

<!-- Banner khuyến mãi -->
<section class="banner">
  <h2>Khuyến mãi siêu hot!</h2>
  <p>Mua ngay hôm nay – Không giảm giá</p>
</section>
