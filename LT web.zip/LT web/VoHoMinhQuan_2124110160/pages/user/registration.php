
<!-- đăng ký -->
  <link rel="stylesheet" href="../../asset/css/styleregstration.css">
<h2>ĐĂNG KÝ THÀNH VIÊN</h2>
<form action ="" method="post" class = "registration-form">
    <div>
        <label>Họ Tên</label>
        <input type ="text" name ="ho_ten" placeholder ="Nhập họ tên">
    </div>
     <div>
        <label>Giới Tính</label>
        <input type ="radio" name ="sex" value="nam">Nam
        <input type ="radio" name ="sex" value="nu">Nữ

    </div> 
    <div>
        <label>Ngày Sinh</label><br>
        <input type ="date" name ="ngay_sinh">
    </div> 
    <div>
        <label>Email</label>
        <input type ="email" name ="email" placeholder ="Hãy nhập Email">
    </div> 
    <div>
        <label>Địa chỉ</label>
        <inpul type = "text" name = "adress" placeholder ="Hãy Nhập địa chỉ của bạn">
    </div>
     <div>
        <labeL>Tên Đăng Nhập</labeL>
        <input type = "text" name = "namelogin" placeholder ="Hãy nhập tên đăng nhập của bạn">
    </div>
     <div>
        <label>Mật Khẩu</label>
        <input type = "password" name = "matkhau">
    </div>
    <div>
        <button style = "submit">Lấy Thông Tin</button>
    </div>
    <a href="http://localhost/VoHoMinhQuan_2124110160/index.php?page=home">Home</a>

</form>

