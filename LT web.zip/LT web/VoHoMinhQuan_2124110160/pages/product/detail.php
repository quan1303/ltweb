<link rel="stylesheet" href="asset/css/detail.css">

<?php
require("config/database.php");
require("lib/coreFunction.php");
$core = new coreFunction();

// Lấy slug từ URL
$slug = isset($_GET['slug']) ? $core->conn->real_escape_string($_GET['slug']) : '';

$sql = "SELECT * FROM product WHERE slug = '$slug' LIMIT 1";
$result = $core->conn->query($sql);
$product = $result->fetch_assoc();

//<!--tang view khi an vao san pham-->
$update_view = "UPDATE product SET views = views +1 WHERE slug = '$slug'";
$core->conn-> query($update_view);
?>


<?php if($product): ?>
  <div class="product-detail">
    <!-- Ảnh -->
    <img src="asset/image/<?= $product['image'] ?>" alt="<?= $product['product_name'] ?>">

    <!-- Nội dung -->
    <div class="info">
      <h2><?= $product['product_name'] ?></h2>
      <p class="price"><?= number_format($value['price'],0,",",".") ?> VND</p>

    <!-- Đánh giá -->
      <div class="rating">
        <i>★</i><i>★</i><i>★</i><i>★</i><i>☆</i>
      </div>

   

    <!-- Mô tả -->
      <p><?= $product['description'] ?></p>


    <!-- Nút mua -->
      <a href="pages/cart/add.php?slug=<?= $product['slug'] ?>&qty=1" 
         class="btn-buy" 
         onclick="return addToCart('<?= $product['slug'] ?>')">Mua ngay</a>
    </div>
  </div>
<?php else: ?>
  <p>Không tìm thấy sản phẩm.</p>
<?php endif; ?>


