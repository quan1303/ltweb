<?php
require("config/database.php"); 
require("lib/coreFunction.php"); 
$core = new coreFunction(); 

$cat_id = isset($_GET['cat_id']) ? (int)$_GET['cat_id'] : 0;  

$category_name = "Tất cả Sản phẩm"; 

if ($cat_id > 0) {    $cate_sql = "SELECT category_name FROM category WHERE id = $cat_id";
    $cate_result = $core->conn->query($cate_sql);

    if ($cate_result && $cate_result->num_rows > 0) {
        $cate_row = $cate_result->fetch_assoc();
        $category_name = $cate_row['category_name'];
    }

    $sql = "SELECT * FROM product WHERE cat_id = $cat_id";
} else {
    $sql = "SELECT * FROM product";
}

$result = $core->conn->query($sql);
?>

<section class="products">
  <h2 class="section-title">
    <?= $category_name ?>  
  </h2>

  <div class="product-list">
    <?php if($result && $result->num_rows > 0): ?>
      <?php while($value = $result->fetch_assoc()): ?>
        <div class="product-card">
          <img src="asset/image/<?= $value['image'] ?>" alt="<?= $value['product_name'] ?>">

          <h3><?= $value['product_name'] ?></h3>
          <p class="price"><?= number_format($value['price'],0,",",".") ?> VND</p>
          <a href="pages/cart/add.php?slug=<?= $value['slug'] ?>" class="btn-buy">Mua ngay</a>
          <a href="index.php?page=productdetail&slug=<?= $value['slug'] ?>" class="btn-detail">Chi tiết</a>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p>Không có sản phẩm trong danh mục này.</p>
    <?php endif; ?>
  </div>
</section>
