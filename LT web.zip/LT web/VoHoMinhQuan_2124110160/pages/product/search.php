<?php
require("config/database.php");
require("lib/coreFunction.php");
$core = new coreFunction();

if (isset($_GET['product_search'])) {
    $search = $core->conn->real_escape_string($_GET['product_search']);

    $sql = "SELECT * FROM product WHERE product_name LIKE '%$search%'";
    $result = $core->conn->query($sql);

    echo "<h2>Kết quả tìm kiếm cho: <b>$search</b></h2>";

    if ($result && $result->num_rows > 0) {
        echo "<div class='product-list'>";
        while ($row = $result->fetch_assoc()) {
            echo "
            <div class='product-card'>
                <img src='asset/image/{$row['image']}' width='200' alt='{$row['product_name']}'>
                <h3>{$row['product_name']}</h3>
                <p>Giá: " . number_format($row['price'], 0, ',', '.') . " VND</p>
                <a href='index.php?page=productdetail&slug={$row['slug']}' class='btn-detail'>Xem chi tiết</a>
            </div>
            ";
        }
        echo "</div>";
    } else {
        echo "<p>Không tìm thấy sản phẩm nào phù hợp.</p>";
    }
} else {
    echo "<p>Vui lòng nhập từ khóa tìm kiếm.</p>";
}
?>
