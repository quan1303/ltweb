<!--2B Tạo file lib/coreFunction.php, xây dựng các hàm cơ bản để lấy dữ liệu-->

<?php
include_once(__DIR__ . "/../config/database.php");
class coreFunction extends Database{ //core kết thừa data
    function setquery($sql) {
        $result = $this -> conn -> query($sql);// truy vấn đến Sql
        if (!$result) {
            die("Query faile" . $this -> conn -> error);
            return $result;
        }
    }
    function getall ($sql){// lấy tất cả sellect
        $result =$this -> setquery($sql);
        $a = array();
        while($value = $result -> fetch_assoc()) {//sd vòng lặp đọc từng giá trị
            $a[] = $value;// đưa từng dòng vào mảng a
        }
        return $a;
    }

    function getone($sql){
        $result = $this ->setquery($sql);
        $a = $result -> fetch_assoc();
        return $a;
    }
}
// class core function giúp thực thi câu lệnh sql và lấy kq dạng mảng
//setquery($sql) hàm thực thi câu truy vấn
//getall($sql) lấy tất cả các dòng trả về
//getone($sql) lấy 1 dòng đầu tiên tả về