<?php

$route = [
    '' => 'pages/user/home.php',
    'registration' => 'pages/user/contact.php',
    'contact' => 'pages/user/registration.php',
    'product' => 'pages/product/product.php',
    'productdetail' => 'pages/product/detail.php',
     'search'        => 'pages/product/search.php'

];
?>


