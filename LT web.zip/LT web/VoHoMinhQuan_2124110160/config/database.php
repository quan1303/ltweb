<!--2A Tạo file lib/db.php, thực hiện kết nối csdl-->
<?php
class Database {
    private $servername = "localhost";
    private $username = "root";
    private $password = "";
    private $dbname = "quan";
    public $conn;

    // Hàm khởi tạo, tự động gọi khi tạo đối tượng
    public function __construct() {
        // Tạo kết nối
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);

        // Kiểm tra kết nối
        if ($this->conn->connect_error) {
            die("Connect thất bại: " . $this->conn->connect_error);
        }
    }
}
?>
