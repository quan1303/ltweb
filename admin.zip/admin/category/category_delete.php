<?php
// session_start();
require_once(__DIR__ . '/../../lib/db.php');
require_once(__DIR__ . '/../../lib/coreFunction.php');

$db = new Database();
$core = new CoreFunction($db);
$id = $_GET['id'] ?? 0;

if ($id) {
    // Kiểm tra xem danh mục có sản phẩm không
    $hasProduct = $core->hasProductInCategory($id);
    
    if ($hasProduct) {
        echo "<script>
                alert('Không thể xóa vì danh mục này vẫn còn sản phẩm!');
                window.location.href='../index.php?page=category_list';
              </script>";
        exit;
    }

    // Xóa mềm (chuyển deleted = 1)
    $core->softDeleteCategory($id);
    echo "<script>
            alert('Đã xóa tạm danh mục thành công!');
            window.location.href='../index.php?page=category_list';
          </script>";
    exit;

} else {
    echo "<script>
            alert('Không tìm thấy danh mục cần xóa!');
            window.location.href='../index.php?page=category_list';
          </script>";
    exit;
}
?>