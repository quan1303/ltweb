<?php
// session_start();
require_once(__DIR__ . '/../../lib/db.php');
require_once(__DIR__ . '/../../lib/coreFunction.php');

$db = new Database();
$core = new CoreFunction($db);
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $slug = strtolower(str_replace(' ', '-', $name));

    $exist = $core->getCategoryBySlug($slug);
    if ($exist) {
        $msg = "⚠️ Danh mục này đã tồn tại!";
    } else {
        $core->addCategory($name, $slug);
        header('Location: ../index.php?page=category_list');
        exit;
    }
}
?>

<div class="admin-main">
  <h2>Thêm danh mục mới</h2>
  <?php if ($msg): ?><p style="color:red;"><?= $msg ?></p><?php endif; ?>
  <form method="POST">
    <label>Tên danh mục:</label>
    <input type="text" name="name" required>
    <button type="submit">Thêm</button>
  </form>
</div>
