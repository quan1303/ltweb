<?php
// session_start();
require_once(__DIR__ . '/../../lib/db.php');
require_once(__DIR__ . '/../../lib/coreFunction.php');

$db = new Database();
$core = new CoreFunction($db);

$id = $_GET['id'] ?? 0;
$msg = '';

$category = $core->getCategoryById($id);
if (!$category) {
    die("⚠️ Danh mục không tồn tại!");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $slug = strtolower(str_replace(' ', '-', $name));

    // Kiểm tra trùng tên hoặc slug
    $exist = $core->getCategoryBySlug($slug);
    if ($exist && $exist['id'] != $id) {
        $msg = "⚠️ Tên danh mục này đã tồn tại!";
    } else {
        $core->updateCategory($id, $name, $slug);
        header('Location: ../index.php?page=category_list');
        exit;
    }
}
?>

<div class="admin-main">
  <h2>Sửa danh mục</h2>
  <?php if ($msg): ?><p style="color:red;"><?= $msg ?></p><?php endif; ?>
  <form method="POST">
    <label>Tên danh mục:</label>
    <input type="text" name="name" value="<?= htmlspecialchars($category['name']) ?>" required>
    <br><br>
    <button type="submit">💾 Cập nhật</button>
  </form>
  <br>
  <a href="../index.php?page=category_list">⬅️ Quay lại danh sách</a>
</div>
