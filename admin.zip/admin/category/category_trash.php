<?php
// session_start();
require_once(__DIR__ . '/../../lib/db.php');
require_once(__DIR__ . '/../../lib/coreFunction.php');

$db = new Database();
$core = new CoreFunction($db);
$deletedCategories = $core->getDeletedCategories();
?>

<h2>🗑️ Danh mục đã xóa tạm</h2>

<?php if (empty($deletedCategories)): ?>
  <p>Không có danh mục nào trong thùng rác.</p>
<?php else: ?>
  <table border="1" cellpadding="8" cellspacing="0" width="100%">
    <tr>
      <th>ID</th>
      <th>Tên danh mục</th>
      <th>Slug</th>
      <th>Hành động</th>
    </tr>

    <?php foreach ($deletedCategories as $c): ?>
      <tr>
        <td><?= $c['id'] ?></td>
        <td><?= htmlspecialchars($c['name']) ?></td>
        <td><?= htmlspecialchars($c['slug']) ?></td>
        <td>
          <a href="category_restore.php?action=restore&id=<?= $c['id'] ?>">♻️ Phục hồi</a> |
          <a href="category_restore.php?action=delete&id=<?= $c['id'] ?>"
             onclick="return confirm('Bạn có chắc muốn xóa hẳn danh mục này khỏi cơ sở dữ liệu không?')">❌ Xóa hẳn</a>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
<?php endif; ?>

<br>
<a href="../index.php?page=category_list">⬅️ Quay lại danh sách danh mục</a>