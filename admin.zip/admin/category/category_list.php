<?php
// session_start();
require_once '../lib/db.php';
require_once '../lib/coreFunction.php';

$db = new Database();
$core = new CoreFunction($db);
$categories = $core->getCategories();
?>

<div class="admin-main">
  <h2>Danh sách danh mục</h2>
  <table border="1" cellpadding="8" cellspacing="0">
    <tr>
      <th>ID</th>
      <th>Tên</th>
      <th>Slug</th>
      <th>Hành động</th>
    </tr>
    <?php foreach ($categories as $cat): ?>
      <tr>
        <td><?= $cat['id'] ?></td>
        <td><?= htmlspecialchars($cat['name']) ?></td>
        <td><?= htmlspecialchars($cat['slug']) ?></td>
        <td>
          <a href="category/category_edit.php?id=<?= $cat['id'] ?>">✏️ Sửa</a> |
          <a href="category/category_delete.php?id=<?= $cat['id'] ?>" onclick="return confirm('Xóa danh mục này?')">🗑️ Xóa</a>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
  <br>
  <a href="category/category_add.php">➕ Thêm danh mục mới</a>
  <a href="category/category_trash.php">🗑️ Danh mục đã xóa</a>

</div>
