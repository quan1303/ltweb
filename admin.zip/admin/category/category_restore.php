<?php
// session_start();
require_once(__DIR__ . '/../../lib/db.php');
require_once(__DIR__ . '/../../lib/coreFunction.php');

$db = new Database();
$core = new CoreFunction($db);

$action = $_GET['action'] ?? '';
$id = $_GET['id'] ?? 0;

if ($id && $action) {
    if ($action === 'restore') {
        // Phục hồi danh mục (đặt deleted = 0)
        $core->restoreCategory($id);
        echo "<script>
                alert('Phục hồi danh mục thành công!');
                window.location.href='category_trash.php';
              </script>";
        exit;
    } elseif ($action === 'delete') {
        // Xóa vĩnh viễn danh mục khỏi CSDL
        $core->deleteCategoryPermanently($id);
        echo "<script>
                alert('Đã xóa hẳn danh mục khỏi cơ sở dữ liệu!');
                window.location.href='category_trash.php';
              </script>";
        exit;
    } else {
        echo "<script>
                alert('Hành động không hợp lệ!');
                window.location.href='category_trash.php';
              </script>";
        exit;
    }
} else {
    echo "<script>
            alert('Thiếu thông tin cần thiết!');
            window.location.href='category_trash.php';
          </script>";
    exit;
}
?>