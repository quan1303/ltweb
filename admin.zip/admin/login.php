<?php
session_start();
if (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin') {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Đăng nhập Admin</title>
  <link rel="stylesheet" href="asset/admin.css">
</head>
<body class="login-body">
  <div class="login-container">
    <h2>Đăng nhập Quản trị</h2>

    <?php if (isset($_GET['error'])): ?>
      <p class="error"><?= htmlspecialchars($_GET['error']) ?></p>
    <?php endif; ?>

    <form method="POST" action="doLogin.php">
      <label>Email</label>
      <input type="email" name="email" required placeholder="Nhập email quản trị">

      <label>Mật khẩu</label>
      <input type="password" name="password" required placeholder="Nhập mật khẩu">

      <button type="submit">Đăng nhập</button>
    </form>
  </div>
</body>
</html>
