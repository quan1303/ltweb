<?php
session_start();
require_once '../lib/db.php';
require_once '../lib/coreFunction.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$page = $_GET['page'] ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="asset/admin.css">
</head>
<body>
  <?php include 'includes/header.php'; ?>
  <div class="admin-layout">
    <?php include 'includes/sidebar.php'; ?>

    <main class="admin-content">
      <?php
        $file = "page/{$page}.php";
        if (file_exists("category/{$page}.php")) {
    include "category/{$page}.php";
      } elseif (file_exists("product/{$page}.php")) {
    include "product/{$page}.php";
      } else {
    echo "<h2>Chào mừng bạn đến trang quản trị</h2>";
}
      ?>
    </main>
  </div>
  
  <?php include 'includes/footer.php'; ?>
</body>
</html>
