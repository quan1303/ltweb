<?php
require_once '../lib/db.php';
require_once '../lib/coreFunction.php';
$db = new Database();
$core = new CoreFunction($db);
$id = $_GET['id'] ?? 0;
$product = $core->getProductById($id);
$categories = $core->getCategories();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $slug = strtolower(str_replace(' ', '-', $name));
    $price = (int)$_POST['price'];
    $category_id = $_POST['category_id'];
    $image = $_POST['image'] ?? '';
    $short_desc = $_POST['short_desc'] ?? '';

    $core->updateProduct($id, $name, $slug, $price, $category_id, $image, $short_desc);
    header('Location: index.php?page=product_list');
    exit;
}
?>
<h2>Sửa sản phẩm</h2>
<form method="POST">
  <label>Tên:</label><br>
  <input type="text" name="name" value="<?= htmlspecialchars($product['name']) ?>" required><br>
  <label>Giá:</label><br>
  <input type="number" name="price" value="<?= $product['price'] ?>" required><br>
  <label>Danh mục:</label><br>
  <select name="category_id">
    <?php foreach ($categories as $c): ?>
      <option value="<?= $c['id'] ?>" <?= ($c['id'] == $product['category_id']) ? 'selected' : '' ?>>
        <?= htmlspecialchars($c['name']) ?>
      </option>
    <?php endforeach; ?>
  </select><br>
  <label>Ảnh:</label><br>
  <input type="text" name="image" value="<?= htmlspecialchars($product['image']) ?>"><br>
  <label>Mô tả ngắn:</label><br>
  <textarea name="short_desc"><?= htmlspecialchars($product['short_desc']) ?></textarea><br>
  <button type="submit">Cập nhật</button>
</form>
