<?php
require_once '../lib/db.php';
require_once '../lib/coreFunction.php';
$db = new Database();
$core = new CoreFunction($db);
$categories = $core->getCategories();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $slug = strtolower(str_replace(' ', '-', $name));
    $price = (int)$_POST['price'];
    $category_id = $_POST['category_id'];
    $image = $_POST['image'] ?? '';
    $short_desc = $_POST['short_desc'] ?? '';

    if ($core->checkDuplicateProduct($name)) {
        $msg = "⚠️ Tên sản phẩm đã tồn tại!";
    } else {
        $core->addProduct($name, $slug, $price, $category_id, $image, $short_desc);
        header('Location: index.php?page=product_list');
        exit;
    }
}
?>
<h2>Thêm sản phẩm mới</h2>
<form method="POST">
  <label>Tên:</label><br>
  <input type="text" name="name" required><br>
  <label>Giá:</label><br>
  <input type="number" name="price" required><br>
  <label>Danh mục:</label><br>
  <select name="category_id">
    <?php foreach ($categories as $c): ?>
      <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
    <?php endforeach; ?>
  </select><br>
  <label>Ảnh (tên file):</label><br>
  <input type="text" name="image"><br>
  <label>Mô tả ngắn:</label><br>
  <textarea name="short_desc" rows="3"></textarea><br>
  <button type="submit">Lưu</button>
</form>
<p style="color:red;"><?= $msg ?></p>
