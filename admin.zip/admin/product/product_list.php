<?php
require_once '../lib/db.php';
require_once '../lib/coreFunction.php';
$db = new Database();
$core = new CoreFunction($db);
$products = $core->getProducts();
?>

<h2>Danh sách sản phẩm</h2>
<a href="index.php?page=product_add" class="btn">➕ Thêm sản phẩm</a>
<table border="1" cellpadding="6" cellspacing="0">
  <tr>
    <th>ID</th><th>Tên</th><th>Danh mục</th><th>Giá</th><th>Ảnh</th><th>Hành động</th>
  </tr>
  <?php foreach ($products as $p): ?>
  <tr>
    <td><?= $p['id'] ?></td>
    <td><?= htmlspecialchars($p['name']) ?></td>
    <td><?= htmlspecialchars($p['category_name']) ?></td>
    <td><?= number_format($p['price'], 0, ',', '.') ?> ₫</td>
    <td><img src="../asset/images/<?= $p['image'] ?>" width="80"></td>
    <td>
      <a href="index.php?page=product_edit&id=<?= $p['id'] ?>">✏️ Sửa</a> |
      <a href="index.php?page=product_delete&id=<?= $p['id'] ?>" onclick="return confirm('Xóa sản phẩm này?')">🗑️ Xóa</a>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
