<?php
require_once '../lib/db.php';
require_once '../lib/coreFunction.php';
$db = new Database();
$core = new CoreFunction($db);
$id = $_GET['id'] ?? 0;

if ($core->deleteProduct($id)) {
    header('Location: index.php?page=product_list');
} else {
    echo "<p style='color:red'>⚠️ Không thể xóa sản phẩm này vì đã có trong đơn hàng!</p>";
    echo "<a href='index.php?page=product_list'>Quay lại</a>";
}
