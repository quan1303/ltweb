<header class="admin-header">
  <div class="admin-logo">🛠️ Trang quản trị</div>
  <nav>
    <a href="index.php">🏠 Trang Chủ</a>
    <a href="logout.php" class="logout-btn">🚪 Đăng xuất</a>
  </nav>
</header>
