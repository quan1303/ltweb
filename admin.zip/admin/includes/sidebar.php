<aside class="admin-sidebar">
  <ul>
    <li><a href="index.php?page=category_list">📁 Quản lý danh mục</a></li>
    <li><a href="index.php?page=product_list">📦 Quản lý sản phẩm</a></li>
    <li><a href="index.php?page=orders">🧾 Đơn hàng</a></li>
    <li><a href="index.php?page=users">👤 Người dùng</a></li>
  </ul>
</aside>
