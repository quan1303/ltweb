<footer class="admin-footer">
  <!-- <p>© <?= date('Y') ?> MinhQuan Admin Dashboard</p> -->
  <p>© <?= date('Y') ?></p>
</footer>
