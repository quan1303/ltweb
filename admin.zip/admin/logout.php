<?php
session_start();
session_unset();
session_destroy();

// Quay về trang home
header("Location: login.php");
exit;
?>
