<?php
session_start();
require_once '../lib/db.php';

$db = new Database();
$conn = $db->pdo();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM user WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && $user['password'] === $password && $user['role'] === 'admin') {
        $_SESSION['user'] = $user;
        header("Location: index.php");
        exit;
    } else {
        header("Location: login.php?error=Tài khoản hoặc mật khẩu không đúng!");
        exit;
    }
}
?>
